CREATE TABLE `hidden_demos` (
	`id` text PRIMARY KEY NOT NULL,
	`deleted_at` text NOT NULL
);
