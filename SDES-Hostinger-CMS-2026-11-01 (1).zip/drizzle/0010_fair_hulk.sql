CREATE TABLE `regular_routes` (
	`id` text PRIMARY KEY NOT NULL,
	`company` text NOT NULL,
	`email` text NOT NULL,
	`customer_code` text DEFAULT '' NOT NULL,
	`origin` text NOT NULL,
	`destination` text NOT NULL,
	`loading_gps` text DEFAULT '' NOT NULL,
	`unloading_gps` text DEFAULT '' NOT NULL,
	`departures_per_week` integer NOT NULL,
	`start_date` text NOT NULL,
	`end_date` text DEFAULT '' NOT NULL,
	`equipment` text NOT NULL,
	`load_type` text NOT NULL,
	`loading_metres` real,
	`return_load` text NOT NULL,
	`schedule_notes` text DEFAULT '' NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`status` text NOT NULL,
	`revision` integer DEFAULT 1 NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `regular_routes_email` ON `regular_routes` (`email`);--> statement-breakpoint
CREATE INDEX `regular_routes_status` ON `regular_routes` (`status`,`updated_at`);