CREATE TABLE `finance_history` (
	`id` text PRIMARY KEY NOT NULL,
	`job_id` text NOT NULL,
	`revision` integer NOT NULL,
	`snapshot` text NOT NULL,
	`created_by` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `finance_history_job` ON `finance_history` (`job_id`,`revision`);--> statement-breakpoint
CREATE TABLE `job_finance` (
	`job_id` text PRIMARY KEY NOT NULL,
	`sale_currency` text NOT NULL,
	`purchase_currency` text NOT NULL,
	`sale_cents` integer,
	`purchase_cents` integer,
	`received_cents` integer DEFAULT 0 NOT NULL,
	`paid_cents` integer DEFAULT 0 NOT NULL,
	`receivable_due` text DEFAULT '' NOT NULL,
	`payable_due` text DEFAULT '' NOT NULL,
	`customer_document` text DEFAULT '' NOT NULL,
	`carrier_document` text DEFAULT '' NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`revision` integer DEFAULT 1 NOT NULL,
	`updated_at` text NOT NULL
);
