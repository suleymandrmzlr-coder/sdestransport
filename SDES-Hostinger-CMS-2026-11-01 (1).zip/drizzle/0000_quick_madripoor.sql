CREATE TABLE `admins` (
	`user_id` text PRIMARY KEY NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `shipment_events` (
	`id` text PRIMARY KEY NOT NULL,
	`shipment_id` text NOT NULL,
	`status` text NOT NULL,
	`location` text NOT NULL,
	`notes` text NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`shipment_id`) REFERENCES `shipments`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `shipment_events_shipment` ON `shipment_events` (`shipment_id`);--> statement-breakpoint
CREATE TABLE `loads` (
	`id` text PRIMARY KEY NOT NULL,
	`reference` text NOT NULL,
	`origin` text NOT NULL,
	`destination` text NOT NULL,
	`pickup_date` text NOT NULL,
	`equipment` text NOT NULL,
	`weight` real,
	`pallets` integer,
	`status` text NOT NULL,
	`details` text NOT NULL,
	`revision` integer DEFAULT 1 NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `loads_reference_unique` ON `loads` (`reference`);--> statement-breakpoint
CREATE TABLE `quotes` (
	`id` text PRIMARY KEY NOT NULL,
	`company` text NOT NULL,
	`email` text NOT NULL,
	`language` text NOT NULL,
	`load_id` text,
	`payload` text NOT NULL,
	`status` text NOT NULL,
	`ip_hash` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `quote_rate` ON `quotes` (`ip_hash`,`created_at`);--> statement-breakpoint
CREATE TABLE `shipments` (
	`id` text PRIMARY KEY NOT NULL,
	`reference` text NOT NULL,
	`origin` text NOT NULL,
	`destination` text NOT NULL,
	`eta` text NOT NULL,
	`status` text NOT NULL,
	`location` text NOT NULL,
	`access_hash` text NOT NULL,
	`revision` integer DEFAULT 1 NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `shipments_reference_unique` ON `shipments` (`reference`);