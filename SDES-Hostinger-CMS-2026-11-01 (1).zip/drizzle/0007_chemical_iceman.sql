CREATE TABLE `job_documents` (
	`id` text PRIMARY KEY NOT NULL,
	`job_id` text NOT NULL,
	`type` text NOT NULL,
	`language` text NOT NULL,
	`number` text NOT NULL,
	`created_at` text NOT NULL,
	`created_by` text NOT NULL,
	`object_key` text NOT NULL,
	`snapshot` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `job_documents_number_unique` ON `job_documents` (`number`);--> statement-breakpoint
CREATE INDEX `job_documents_job` ON `job_documents` (`job_id`,`created_at`);