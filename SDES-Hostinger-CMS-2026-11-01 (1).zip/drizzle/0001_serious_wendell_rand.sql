CREATE TABLE `articles` (
	`slug` text PRIMARY KEY NOT NULL,
	`status` text NOT NULL,
	`content` text NOT NULL,
	`revision` integer DEFAULT 1 NOT NULL
);
