ALTER TABLE `shipments` ADD `public_origin` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `shipments` ADD `public_destination` text DEFAULT '' NOT NULL;