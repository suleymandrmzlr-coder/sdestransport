ALTER TABLE `loads` ADD `source_quote_id` text REFERENCES quotes(id);--> statement-breakpoint
ALTER TABLE `loads` ADD `intake` text DEFAULT '{}' NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX `loads_source_quote_id_unique` ON `loads` (`source_quote_id`);