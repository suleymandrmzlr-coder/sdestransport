ALTER TABLE `loads` ADD `public_origin` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `loads` ADD `public_destination` text DEFAULT '' NOT NULL;