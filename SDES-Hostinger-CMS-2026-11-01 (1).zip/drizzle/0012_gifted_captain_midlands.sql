ALTER TABLE `loads` ADD `deleted_at` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `shipments` ADD `deleted_at` text DEFAULT '' NOT NULL;