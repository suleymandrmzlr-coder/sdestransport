ALTER TABLE `loads` ADD `customer_code` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `loads` ADD `carrier_name` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `shipments` ADD `load_id` text REFERENCES loads(id);--> statement-breakpoint
CREATE UNIQUE INDEX `shipments_load_id_unique` ON `shipments` (`load_id`);
