ALTER TABLE `loads` ADD `origin_country` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `loads` ADD `destination_country` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `shipments` ADD `tractor_plate` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `shipments` ADD `trailer_plate` text DEFAULT '' NOT NULL;