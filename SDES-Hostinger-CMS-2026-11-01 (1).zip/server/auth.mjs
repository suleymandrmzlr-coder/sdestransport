import {randomBytes,scrypt as scryptCb,timingSafeEqual,createHash} from 'node:crypto';import {promisify} from 'node:util';
const scrypt=promisify(scryptCb);export const hash=v=>createHash('sha256').update(v).digest('hex');
export const modules=['content','translations','media','seo','settings','operations','enquiries','documents','finance','routes','blog','customers'];
export const permissions=modules.flatMap(m=>[m+'.read',m+'.write']);
export const allowed=(u,p)=>!!u&&(u.role==='owner'||u.permissions.includes(p));
export async function passwordHash(password){if(typeof password!=='string'||password.length<12||password.length>128)throw Error('Password must contain 12–128 characters.');const salt=randomBytes(16).toString('hex');return salt+':'+(await scrypt(password,salt,64)).toString('hex')}
export async function verifyPassword(password,stored){try{const [salt,key]=stored.split(':'),actual=await scrypt(String(password),salt,64),expected=Buffer.from(key,'hex');return actual.length===expected.length&&timingSafeEqual(actual,expected)}catch{return false}}
export async function sessionUser(req,db){const cookie=(req.headers.cookie||'').split(';').map(v=>v.trim()).find(v=>v.startsWith('sdes_session='));if(!cookie)return null;const token=cookie.slice(13);if(!/^[a-f0-9]{64}$/.test(token))return null;const u=await db.prepare('SELECT u.* FROM cms_users u JOIN cms_sessions s ON s.user_id=u.id WHERE s.token_hash=? AND s.expires_at>? AND u.active=1').bind(hash(token),Date.now()).first();if(!u)return null;return {...u,permissions:JSON.parse(u.permissions),password_hash:undefined};}
export async function loginRoutes(req,res,db){
 const body=req.body||{},now=Date.now();
 if(req.path==='/api/auth/status'){const n=await db.prepare('SELECT COUNT(*) AS n FROM cms_users').first();return res.json({setupRequired:!n.n,user:req.user,permissions});}
 if(req.path==='/api/auth/logout'){const cookie=(req.headers.cookie||'').split(';').map(v=>v.trim()).find(v=>v.startsWith('sdes_session='));if(cookie)await db.prepare('DELETE FROM cms_sessions WHERE token_hash=?').bind(hash(cookie.slice(13))).run();res.clearCookie('sdes_session',{path:'/'});return res.json({ok:true});}
 if(!['/api/auth/login','/api/auth/setup'].includes(req.path))return res.status(404).json({error:'Not found'});
 const bucket=hash('login:'+req.ip),r=await db.prepare('SELECT * FROM cms_login_limits WHERE bucket=?').bind(bucket).first();if(r&&r.expires_at>now&&r.attempts>=10)return res.status(429).json({error:'Too many attempts. Try again in 15 minutes.'});
 await db.prepare('INSERT INTO cms_login_limits(bucket,attempts,expires_at) VALUES(?,1,?) ON DUPLICATE KEY UPDATE attempts=IF(expires_at<?,1,attempts+1),expires_at=IF(expires_at<?,VALUES(expires_at),expires_at)').bind(bucket,now+900000,now,now).run();
 if(req.path.endsWith('/setup')){
 const token=process.env.SETUP_TOKEN||'';if(!/^[a-f0-9]{64}$/i.test(token)||hash(body.token||'')!==hash(token))return res.status(403).json({error:'Invalid setup token'});
 if((await db.prepare('SELECT COUNT(*) AS n FROM cms_users').first()).n)return res.status(409).json({error:'Setup has already been completed.'});
 const email=String(body.email||'').trim().toLowerCase();if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||email.length>200)return res.status(400).json({error:'Invalid email'});
 // Fixed primary key prevents concurrent setup from creating multiple owners.
 await db.prepare("INSERT INTO cms_users(id,email,name,password_hash,role,permissions,active,revision,created_at) VALUES('owner',?,?,?,'owner','[]',1,1,?)").bind(email,String(body.name||'Administrator').slice(0,180),await passwordHash(body.password),new Date().toISOString()).run();
 }
 const user=await db.prepare('SELECT * FROM cms_users WHERE email=? AND active=1').bind(String(body.email||'').trim().toLowerCase()).first();
 if(!user||!await verifyPassword(body.password,user.password_hash))return res.status(401).json({error:'Email or password is incorrect.'});
 const session=randomBytes(32).toString('hex');await db.prepare('INSERT INTO cms_sessions(token_hash,user_id,expires_at) VALUES(?,?,?)').bind(hash(session),user.id,now+8*3600000).run();
 await db.prepare('DELETE FROM cms_sessions WHERE expires_at<?').bind(now).run();await db.prepare('DELETE FROM cms_login_limits WHERE expires_at<? OR bucket=?').bind(now,bucket).run();
 res.cookie('sdes_session',session,{httpOnly:true,secure:process.env.NODE_ENV!=='test',sameSite:'lax',path:'/',maxAge:8*3600000});return res.json({ok:true});
}
export function permissionFor(path,method){const mode=method==='GET'?'read':'write',p=path.replace(/^\/api\//,'');
 const group=p.includes('finance')?'finance':p.includes('document')?'documents':p.includes('article')?'blog':p.includes('image')?'media':p.includes('regular-route')?'routes':p.includes('customer')?'customers':p.includes('quote-job')?'operations':p.includes('quote')?'enquiries':'operations';return group+'.'+mode;}
