import {readFileSync,existsSync} from 'node:fs';import {createDatabase,createBucket} from './db.mjs';import {makeSeed} from './seed.mjs';import {renderJobPDF} from '../lib/job-pdf.mjs';
try{process.loadEnvFile()}catch(e){if(e.code!=='ENOENT')throw e}
const db=createDatabase();
try{
 if(!process.env.DB_NAME||!process.env.DB_USER)throw Error('Set DB_NAME, DB_USER and DB_PASSWORD first. See HOSTINGER-KURULUM.md.');
 const connection=await db.connection();try{const schema=readFileSync(new URL('../database/schema-mariadb.sql',import.meta.url),'utf8');for(const statement of schema.split(';').map(x=>x.trim()).filter(Boolean))await connection.query(statement)}finally{connection.release()}
 const seed=makeSeed(),batch=[];for(const [code,name]of [['en','English'],['es','Español'],['tr','Türkçe'],['de','Deutsch']])batch.push(db.prepare('INSERT IGNORE INTO cms_languages(code,name,enabled) VALUES(?,?,1)').bind(code,name));
 for(const p of seed.pages){batch.push(db.prepare('INSERT IGNORE INTO cms_pages(id,template,title) VALUES(?,?,?)').bind(p.id,p.template,p.title.slice(0,200)));for(const code of ['en','es','tr','de']){const base=p.variants[code]||p.variants.en;batch.push(db.prepare('INSERT IGNORE INTO cms_content(page_id,locale,slug,title,description,fields,revision,noindex) VALUES(?,?,?,?,?,?,1,?)').bind(p.id,code,p.id==='home'?'':p.id,base.title,base.description,'{}',(p.id.startsWith('article')||['tracking','load-detail','loads'].includes(p.id))?1:0))}}
 batch.push(db.prepare('INSERT IGNORE INTO cms_settings(id,value,revision) VALUES(?,?,1)').bind('appearance',JSON.stringify({defaultTheme:'light',primary:'#183e68',accent:'#dd6f2d'})));await db.batch(batch);
 if(process.argv.includes('--import-existing')){
  if(await db.prepare("SELECT id FROM cms_settings WHERE id='migration_completed'").first())throw Error('Existing-data import already completed. It will not be repeated.');
  const data=JSON.parse(readFileSync(new URL('../database/live-records.json',import.meta.url),'utf8'));
  const tables=['quotes','loads','shipments','shipment_events','hidden_demos','articles','regular_routes','job_documents','job_finance','finance_history'];
  for(const t of tables)if(Number((await db.prepare('SELECT COUNT(*) AS n FROM `'+t+'`').first()).n))throw Error('Import requires an empty operations database: '+t+' is not empty. No records were overwritten.');
  const writes=[];for(const t of tables){const table=data.tables[t];if(!table)continue;for(const row of table.rows){const cols=table.columns;writes.push(db.prepare('INSERT INTO `'+t+'`('+cols.map(c=>'`'+c+'`').join(',')+') VALUES('+cols.map(()=>'?').join(',')+')').bind(...cols.map(c=>row[c]??null)))}}
  // Original object storage is not exportable through the available connector.
  // Regenerate archived PDFs from their complete saved snapshots; preserve metadata and object keys.
  for(const row of data.tables.job_documents?.rows||[]){const snapshot=JSON.parse(row.snapshot),pdf=await renderJobPDF(snapshot);writes.push(db.prepare('INSERT INTO stored_objects(object_key,content_type,content,created_at) VALUES(?,?,?,?)').bind(row.object_key,'application/pdf',Buffer.from(pdf),new Date().toISOString()))}
  writes.push(db.prepare('INSERT INTO cms_settings(id,value,revision) VALUES(?,?,1)').bind('migration_completed',JSON.stringify({at:new Date().toISOString(),source:data.source,pdfs:'regenerated-from-snapshots'})));await db.batch(writes);console.log('Existing records imported. Archived PDFs regenerated from saved snapshots.');
 }
 console.log('Database ready. Visit /cms to create your owner account with SETUP_TOKEN. No default password exists.');
}finally{await db.close()}
