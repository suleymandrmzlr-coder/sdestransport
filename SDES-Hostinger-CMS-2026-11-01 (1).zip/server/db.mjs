import mysql from 'mysql2/promise';
// Small compatibility boundary for the existing, tested SQLite-oriented domain queries.
// All values remain bound parameters. No user SQL is accepted.
export function mariaSQL(input,lastChanges=0){
 let sql=input.replace(/\bINSERT OR IGNORE\b/gi,'INSERT IGNORE').replace(/ON CONFLICT\((\w+)\) DO NOTHING/gi,(_,k)=>`ON DUPLICATE KEY UPDATE ${k}=${k}`).replace(/\bchanges\(\)/gi,String(Number(lastChanges)||0));
 // JSON_EXTRACT in MariaDB returns JSON strings, whereas SQLite returns scalar strings.
 const matches=[...sql.matchAll(/\bjson_extract\s*\(/gi)];
 for(const m of matches.reverse()){let depth=1,quote='',i=m.index+m[0].length;for(;i<sql.length&&depth;i++){const c=sql[i];if(quote){if(c===quote){if(sql[i+1]===quote)i++;else quote='';}}else if("'\"`".includes(c))quote=c;else if(c==='(')depth++;else if(c===')')depth--;}
 if(depth===0)sql=sql.slice(0,m.index)+'JSON_UNQUOTE('+sql.slice(m.index,i)+')'+sql.slice(i);}
 // MariaDB requires aliases on derived tables, SQLite does not.
 const starts=[...sql.matchAll(/\b(?:FROM|JOIN)\s*\(/gi)];let n=0;
 for(const m of starts.reverse()){let d=1,q='',i=m.index+m[0].length;for(;i<sql.length&&d;i++){let c=sql[i];if(q){if(c===q){if(sql[i+1]===q)i++;else q='';}}else if("'\"`".includes(c))q=c;else if(c==='(')d++;else if(c===')')d--;}
 const tail=sql.slice(i).trimStart();if(d===0&&(!tail||/^(WHERE|GROUP|ORDER|LIMIT|UNION|HAVING|JOIN|LEFT|RIGHT|INNER|CROSS)\b|^[),;]/i.test(tail)))sql=sql.slice(0,i)+' AS derived_'+(++n)+' '+sql.slice(i);}
 return sql;
}
export function createDatabase(config={}){
 const pool=mysql.createPool({host:process.env.DB_HOST||'127.0.0.1',port:Number(process.env.DB_PORT||3306),user:process.env.DB_USER,password:process.env.DB_PASSWORD,database:process.env.DB_NAME,connectionLimit:5,charset:'utf8mb4',decimalNumbers:true,flags:'-FOUND_ROWS',...config});
 async function connection(){const c=await pool.getConnection();await c.query("SET SESSION sql_mode='STRICT_TRANS_TABLES,NO_BACKSLASH_ESCAPES,PIPES_AS_CONCAT'");return c;}
 async function execute(c,s,last=0){try{const [r]=await c.execute(mariaSQL(s.sql,last),s.args);return Array.isArray(r)?{results:r}:{meta:{changes:r.affectedRows}}}catch(e){if(e.code==='ER_DUP_ENTRY')throw new Error('UNIQUE constraint: duplicate_reference');throw e;}}
 const db={prepare(sql){const s={sql,args:[],bind(...args){return {...s,args,bind:s.bind,first:s.first,all:s.all,run:s.run}},async first(){return (await this.all()).results[0]||null},async all(){const c=await connection();try{return await execute(c,this)}finally{c.release()}},async run(){return this.all()}};return s;},async batch(list){const c=await connection();try{await c.beginTransaction();let changes=0;const results=[];for(const s of list){const r=await execute(c,s,changes);if(r.meta)changes=r.meta.changes;results.push(r)}await c.commit();return results}catch(e){await c.rollback();throw e}finally{c.release()}},pool,connection,close:()=>pool.end()};return db;
}
export function createBucket(db){return {async put(key,bytes,options={}){await db.prepare('INSERT INTO stored_objects(object_key,content_type,content,created_at) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE content_type=VALUES(content_type),content=VALUES(content)').bind(key,options.httpMetadata?.contentType||'application/octet-stream',Buffer.from(bytes),new Date().toISOString()).run()},async get(key){const r=await db.prepare('SELECT content,content_type FROM stored_objects WHERE object_key=?').bind(key).first();return r?{body:r.content,httpMetadata:{contentType:r.content_type}}:null},async delete(key){await db.prepare('DELETE FROM stored_objects WHERE object_key=?').bind(key).run()}}}
