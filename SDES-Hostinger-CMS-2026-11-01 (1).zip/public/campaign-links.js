(function(root){'use strict';
function campaignLink(origin,data){
 const {language,destination,source,medium,campaign,content=''}=data;
 if(!['en','es','tr'].includes(language)||!['quote','regular','routes','blog'].includes(destination)||!['cpc','paid_social','organic_social','email','referral'].includes(medium))throw Error('adsInvalid');
 if(![source,campaign].every(x=>typeof x==='string'&&/^[A-Za-z0-9_-]{1,80}$/.test(x))||(content&&!/^[A-Za-z0-9_-]{1,80}$/.test(content)))throw Error('adsInvalid');
 const base=new URL(origin);if(!['https:','http:'].includes(base.protocol))throw Error('adsInvalid');
 const suffix=language==='en'?'':'-'+language;
 const path=destination==='routes'?'freight-routes'+suffix+'.html':destination==='blog'?'blog'+suffix+'.html':({en:'index.html',es:'es.html',tr:'tr.html'})[language];
 const url=new URL('/'+path,base.origin);
 if(destination==='regular')url.searchParams.set('intent','regular');
 for(const [k,v] of Object.entries({utm_source:source,utm_medium:medium,utm_campaign:campaign,utm_content:content}))if(v)url.searchParams.set(k,v);
 if(['quote','regular'].includes(destination))url.hash='iletisim';
 return url.href;
}
root.SDESCampaignLink=campaignLink;
if(typeof module!=='undefined')module.exports=campaignLink;
})(typeof window!=='undefined'?window:globalThis);
