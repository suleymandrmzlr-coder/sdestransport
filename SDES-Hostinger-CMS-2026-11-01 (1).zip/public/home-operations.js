'use strict';
(()=>{const lang=document.documentElement.lang,S=k=>window.SDES_OPS[lang][k]||k,f=document.getElementById('quoteForm'),notice=document.getElementById('enquiryStatus'),send=document.getElementById('sendEnquiry');
async function api(path,data){const r=await fetch('/api/'+path,{method:data?'POST':'GET',headers:data?{'Content-Type':'application/json'}:{},body:data?JSON.stringify(data):undefined});let j;try{j=await r.json()}catch{throw Error('temporarily_unavailable')}if(!r.ok)throw Error(j.error||'temporarily_unavailable');return j}
const email=f.elements.email,emailError=document.getElementById('enquiryEmailError');
function validateEmail(clean=false,show=false){
 if(clean)email.value=email.value.replace(/^[\s\u200B\uFEFF]+|[\s\u200B\uFEFF]+$/g,'');
 email.setCustomValidity('');const raw=email.value,empty=!raw.trim(),invalid=!empty&&(email.validity.typeMismatch||raw.length>200||! /^[^\s@\u200B\uFEFF]+@[^\s@\u200B\uFEFF]+\.[^\s@\u200B\uFEFF]+$/.test(raw));
 const msg=empty?S('emailRequired'):invalid?S('invalid_email'):'';email.setCustomValidity(msg);email.setAttribute('aria-invalid',String(!!msg&&show));if(emailError)emailError.textContent=show?msg:'';return !msg;
}
email.addEventListener('input',()=>validateEmail(false,false));email.addEventListener('blur',()=>validateEmail(true,false));
f.addEventListener('pointerdown',e=>{if(e.target.closest('button'))validateEmail(true,false)},true);f.addEventListener('keydown',e=>{if(e.key==='Enter')validateEmail(true,false)},true);
f.addEventListener('invalid',e=>{if(e.target===email)validateEmail(true,true);notice.classList.add('error');notice.textContent=e.target===email?(email.validationMessage||S('invalid_email')):S('formInvalid')},true);
send.addEventListener('click',async()=>{if(!validateEmail(true,true)){notice.classList.add('error');notice.textContent=S(email.value?'invalid_email':'emailRequired');email.focus();return}if(!f.reportValidity())return;send.disabled=true;notice.classList.remove('error');notice.textContent=S('saving');const payload=Object.fromEntries(new FormData(f));payload.language=lang;payload.serviceCode=f.elements.service.value;payload.service=f.elements.service.selectedOptions[0].textContent;try{const r=await api('quotes',payload);notice.textContent=S('sent')+' '+r.id;if(typeof summaryText!=='undefined'&&summaryText){summaryText=summaryText.replace(T('Bu özet henüz SDES’e gönderilmemiştir.'),S('sent')+' '+r.id);document.getElementById('summary').textContent=summaryText}}catch(e){notice.classList.add('error');notice.textContent=S(e.message)||S('sendFailed')}finally{send.disabled=false}});
document.querySelectorAll('.languages a').forEach(a=>a.addEventListener('click',()=>{const u=new URL(a.href);u.search=location.search;u.hash=location.hash;a.href=u.href}));
})();
