'use strict';
(()=>{
const form=document.getElementById('quoteForm'),frequency=document.getElementById('shipmentFrequency'),fields=document.getElementById('regularFields');
function update(){fields.hidden=frequency.value!=='regular';fields.disabled=fields.hidden;form.elements.destination.required=!fields.hidden}
function select(value){frequency.value=value==='regular'?'regular':'one_off';update();const u=new URL(location.href);u.searchParams.set('intent',frequency.value==='regular'?'regular':'shipper');u.searchParams.delete('load');history.replaceState(null,'',u)}
frequency.addEventListener('change',()=>select(frequency.value));
document.querySelectorAll('[data-intake]').forEach(b=>b.addEventListener('click',()=>select(b.dataset.intake)));
const params=new URLSearchParams(location.search);if(params.get('intent')==='regular')frequency.value='regular';if(params.get('intent')==='carrier'||params.has('load'))select('shipper');update();
})();
(()=>{
 const dictionary=window.SDES_OPS[document.documentElement.lang];
 for(const key of ['loadingCoordinates','unloadingCoordinates']){
  const input=document.getElementById(key),link=document.getElementById(key+'Map'),error=document.getElementById(key+'Error');
  function validate(){const raw=input.value.trim(),m=raw.match(/^([+-]?\d+(?:\.\d+)?)\s*,\s*([+-]?\d+(?:\.\d+)?)$/),valid=!raw||!!(m&&Math.abs(Number(m[1]))<=90&&Math.abs(Number(m[2]))<=180);input.setCustomValidity(valid?'':dictionary.invalid_coordinates);input.setAttribute('aria-invalid',String(!valid));error.textContent=valid?'':dictionary.invalid_coordinates;link.hidden=!raw||!valid;if(raw&&valid)link.href='https://www.google.com/maps/search/?api=1&query='+encodeURIComponent(m[1]+', '+m[2]);else link.removeAttribute('href')}
  input.addEventListener('input',validate);input.addEventListener('change',validate);validate();
 }
})();
(()=>{
 const f=document.getElementById('quoteForm'),service=f.elements.service,type=f.elements.loadType,group=document.getElementById('loadTypeFields'),field=document.getElementById('loadingMetresField'),input=f.elements.loadingMetres,error=document.getElementById('ldmError'),dict=window.SDES_OPS[document.documentElement.lang];
 function validate(){const raw=input.value.trim().replace(',','.'),valid=input.disabled||(/^\d+(?:\.\d+)?$/.test(raw)&&Number.isFinite(Number(raw))&&Number(raw)>0);input.setCustomValidity(valid?'':dict.invalid_loading_metres);input.setAttribute('aria-invalid',String(!valid&&!!input.value));error.textContent=valid||!input.value?'':dict.invalid_loading_metres}
 function update(fromService=false){const freight=['Komple yük (FTL)','Parsiyel yük (LTL)','Frigorifik taşıma'].includes(service.value);group.hidden=!freight;group.disabled=!freight;if(fromService&&service.value==='Komple yük (FTL)')type.value='ftl';if(fromService&&service.value==='Parsiyel yük (LTL)')type.value='ltl';const partial=freight&&type.value==='ltl';field.hidden=!partial;input.disabled=!partial;input.required=partial;validate()}
 service.addEventListener('change',()=>update(true));type.addEventListener('change',()=>{if(['Komple yük (FTL)','Parsiyel yük (LTL)'].includes(service.value)){service.value=type.value==='ltl'?'Parsiyel yük (LTL)':'Komple yük (FTL)';service.dispatchEvent(new Event('change'))}update()});
 document.querySelectorAll('[data-service]').forEach(a=>a.addEventListener('click',()=>update(true)));
 input.addEventListener('input',validate);input.addEventListener('change',validate);update(true);
})();
