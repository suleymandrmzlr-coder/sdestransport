// Add verified SDES contact details here when available. No guessed accounts or phone numbers.
window.SDES_CONTACT={email:'',whatsapp:'',social:{LinkedIn:'',Instagram:'',Facebook:'',YouTube:''}};
