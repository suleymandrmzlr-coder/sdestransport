import {test} from 'node:test';import assert from 'node:assert/strict';import {DatabaseSync} from 'node:sqlite';import {readFileSync,readdirSync} from 'node:fs';import {handleApi} from '../lib/sdes-api.mjs';
function database(){const sql=new DatabaseSync(':memory:');for(const file of readdirSync(new URL('../drizzle/',import.meta.url)).filter(x=>x.endsWith('.sql')).sort())sql.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));class Statement{constructor(q){this.q=q;this.args=[]}bind(...args){this.args=args;return this}async first(){return sql.prepare(this.q).get(...this.args)||null}async all(){return {results:sql.prepare(this.q).all(...this.args)}}async run(){return {meta:{changes:Number(sql.prepare(this.q).run(...this.args).changes)}}}}return {prepare:q=>new Statement(q),async batch(list){sql.exec('BEGIN');try{const results=[];for(const p of list)results.push(await p.run());sql.exec('COMMIT');return results}catch(e){sql.exec('ROLLBACK');throw e}}}}
const env={DB:database(),ADMIN_BOOTSTRAP_EMAIL:'owner@example.test'},owner={'oai-authenticated-user-id':'test-owner-id','oai-authenticated-user-email':'owner@example.test'},other={'oai-authenticated-user-id':'other-id','oai-authenticated-user-email':'other@example.test'};
async function call(path,data,user={},origin='https://sdes.test'){const r=await handleApi(new Request('https://sdes.test/api/'+path,{method:data?'POST':'GET',headers:{...user,...(data?{'Content-Type':'application/json',origin}:{})},body:data?JSON.stringify(data):undefined}),env);return {status:r.status,data:await r.json()}}
const load={reference:'TEST-LOAD',origin:'Madrid',destination:'Istanbul',pickup_date:'2026-10-26',equipment:'reefer',weight:20000,pallets:33,status:'available',details:{en:'Test freight',es:'Carga de prueba',tr:'Test yükü'}};
test('authorization, persistence, multilingual publishing and quote lifecycle',async()=>{assert.equal((await call('admin/dashboard')).status,401);assert.equal((await call('admin/dashboard',null,other)).status,403);assert.equal((await call('admin/dashboard',null,owner)).status,200);assert.equal((await call('admin/load',load,owner,'https://evil.test')).status,403);assert.equal((await call('admin/load',{...load,details:{en:'Only English'}},owner)).data.error,'all_languages_required');const created=await call('admin/load',load,owner);assert.equal(created.status,200);const id=created.data.id;let list=await call('loads',null,owner);assert.equal(list.data.loads.length,1);assert.equal(list.data.loads[0].details.es,'Carga de prueba');assert.equal((await call('admin/load',{...load,id,revision:0},owner)).status,400);assert.equal((await call('admin/load',{...load,id,revision:1,status:'reserved'},owner)).status,200);assert.equal((await call('loads',null,owner)).data.loads.length,0);assert.equal((await call('admin/load',{...load,id,revision:1},owner)).status,409);assert.equal((await call('admin/load',{...load,id,revision:2},owner)).status,200);const quote=await call('quotes',{company:'Test company',email:'a@example.test',language:'es',notes:'Test quote'});assert.equal(quote.status,201);const dash=(await call('admin/dashboard',null,owner)).data;assert.equal(dash.quotes.length,1);assert.equal(dash.quotes[0].language,'es');assert.equal((await call('admin/quote',{id:quote.data.id,status:'contacted',revision:1},owner)).status,200);assert.equal((await call('admin/load',load,owner)).data.error,'duplicate_reference')});
test('private tracking keys, history, key rotation and stale updates',async()=>{const s={reference:'TEST-SHIP',origin:'Valencia',destination:'Baku',eta:'2026-11-01',status:'planned',location:'Valencia',notes:{en:'Planned',es:'Planificado',tr:'Planlandı'}};const create=await call('admin/shipment',s,owner);assert.equal(create.status,200);const{id,accessKey}=create.data;assert.equal(accessKey.length,40);assert.equal((await call('track',{reference:s.reference,accessKey:'0'.repeat(40)})).status,404);let r=await call('track',{reference:s.reference,accessKey});assert.equal(r.status,200);assert.equal(r.data.events.length,1);assert.ok(!('access_hash' in r.data.shipment));assert.equal((await call('admin/shipment',{...s,id,revision:1,status:'in_transit'},owner)).status,200);assert.equal((await call('admin/shipment',{...s,id,revision:1,status:'delivered'},owner)).status,409);r=await call('track',{reference:s.reference,accessKey});assert.equal(r.data.events.length,2);assert.equal(r.data.shipment.status,'in_transit');const rotated=await call('admin/shipment/key',{id},owner);assert.equal((await call('track',{reference:s.reference,accessKey})).status,404);assert.equal((await call('track',{reference:s.reference,accessKey:rotated.data.accessKey})).status,200);const dashboard=(await call('admin/dashboard',null,owner)).data;assert.ok(!('access_hash' in dashboard.shipments[0]));assert.ok(!('accessKey' in dashboard.shipments[0]))});
test('invalid dates and negative values rejected',async()=>{assert.equal((await call('admin/load',{...load,pickup_date:'2026-02-30'},owner)).data.error,'invalid_fields');assert.equal((await call('admin/load',{...load,weight:-1},owner)).data.error,'invalid_fields')});
test('blog drafts, translations, edits and image validation',async()=>{assert.equal((await call('admin/articles')).status,401);const a=(await call('articles')).data.articles[0];assert.ok(a.image);const b={...a,revision:0,sources:[],status:'draft'};for(const l of ['en','es','tr'])b[l]={...a[l],body:a[l].body.join('\n\n')};assert.equal((await call('admin/article',b,owner)).status,200);assert.ok(!(await call('articles')).data.articles.some(x=>x.slug===a.slug));assert.equal((await call('admin/article',b,owner)).status,409);b.revision=1;b.status='published';b.tr.alt='';assert.equal((await call('admin/article',b,owner)).data.error,'all_languages_required');b.tr.alt='Görsel';assert.equal((await call('admin/article',b,owner)).status,200);assert.ok((await call('articles')).data.articles.some(x=>x.slug===a.slug));const objects=new Map();env.BUCKET={put:async(k,v,opts)=>objects.set(k,{body:v,httpMetadata:opts.httpMetadata}),get:async k=>objects.get(k)};const upload=async(bytes,type='image/png')=>handleApi(new Request('https://sdes.test/api/admin/image',{method:'POST',headers:{...owner,origin:'https://sdes.test','content-type':type},body:new Uint8Array(bytes)}),env);assert.equal((await upload([1,2,3])).status,400);const r=await upload([137,80,78,71,13,10,26,10,0,0]);assert.equal(r.status,200);const {image}=await r.json();const media=await handleApi(new Request('https://sdes.test'+image),env);assert.equal(media.headers.get('Content-Type'),'image/png');assert.equal((await upload([1],'image/svg+xml')).status,400)});
test('all administration routes reject anonymous and unrelated accounts',async()=>{for(const path of ['admin/load','admin/shipment','admin/shipment/key','admin/quote','admin/article','admin/image','admin/demo/delete']){assert.equal((await call(path,{},{})).status,401,path);assert.equal((await call(path,{},other)).status,403,path)}assert.equal((await call('admin/articles',null,other)).status,403);assert.equal((await call('admin/demo/delete',{id:'demo-load-1'},owner,'https://evil.test')).status,403)});
test('demo records are fictional, non-bookable and deletion persists without changing real loads',async()=>{const initial=await call('demos');assert.equal(initial.data.loads.length,3);assert.equal(initial.data.shipments.length,2);assert.ok(initial.data.loads.every(x=>x.demo&&x.reference.startsWith('DEMO-')));assert.ok(initial.data.shipments.every(x=>x.events.length===3&&!x.accessKey&&!x.access_hash));assert.equal((await call('quotes',{company:'Test',email:'test@example.test',language:'en',loadId:'demo-load-1'})).data.error,'carrier_intake_closed');const count=(await call('loads',null,owner)).data.loads.length;assert.equal((await call('admin/demo/delete',{id:'demo-load-1'},owner)).status,200);assert.equal((await call('demos')).data.loads.length,2);assert.equal((await call('loads',null,owner)).data.loads.length,count);assert.equal((await call('admin/demo/delete',{id:'demo-shipment-1'},owner)).status,200);assert.equal((await call('demos')).data.shipments.length,1);assert.equal((await call('admin/demo/delete',{id:'real-id'},owner)).status,404)});
test('country badges and private vehicle plates persist through authorized edits',async()=>{const created=await call('admin/load',{...load,reference:'COUNTRY-TEST',origin_country:'es',destination_country:'TR'},owner);assert.equal(created.status,200);let row=(await call('loads?id='+created.data.id,null,owner)).data.loads[0];assert.equal(row.origin_country,'ES');assert.equal(row.destination_country,'TR');assert.equal((await call('admin/load',{...load,reference:'BAD-COUNTRY',origin_country:'ESP'},owner)).status,400);const s={reference:'PLATE-TEST',origin:'Madrid',destination:'Istanbul',eta:'2026-11-03',status:'in_transit',location:'Lyon',tractor_plate:'TEST-TRACTOR',trailer_plate:'TEST-TRAILER',notes:{en:'Test',es:'Prueba',tr:'Deneme'}};const c=await call('admin/shipment',s,owner);assert.equal(c.status,200);let result=await call('track',{reference:s.reference,accessKey:c.data.accessKey});assert.equal(result.data.shipment.tractor_plate,s.tractor_plate);assert.equal(result.data.shipment.trailer_plate,s.trailer_plate);assert.equal((await call('track',{reference:s.reference,accessKey:'0'.repeat(40)})).status,404);assert.equal((await call('admin/shipment',{...s,id:c.data.id,revision:1,trailer_plate:'NEW-TRAILER'},owner)).status,200);result=await call('track',{reference:s.reference,accessKey:c.data.accessKey});assert.equal(result.data.shipment.trailer_plate,'NEW-TRAILER');assert.equal(result.data.events.length,2)});
test('regular customer enquiries persist while public carrier intake and load browsing are closed',async()=>{
 const regular={company:'Regular customer',email:'regular@example.test',language:'tr',requestType:'shipper',shipmentFrequency:'regular',origin:'Frankfurt',destination:'Madrid',departuresPerWeek:'3',startDate:'2026-11-01',vehicleRequirement:'Curtain-side',returnLoad:'yes'};
 assert.equal((await call('quotes',{...regular,departuresPerWeek:'0'})).status,400);
 assert.equal((await call('quotes',{...regular,destination:''})).status,400);
 const result=await call('quotes',regular);assert.equal(result.status,201);
 assert.equal((await call('quotes',{...regular,requestType:'carrier'})).status,403);
 assert.equal((await call('quotes',{...regular,loadId:'any-load'})).status,403);
 assert.equal((await call('loads')).status,401);
 assert.equal((await call('loads',null,other)).status,403);
 assert.equal((await call('loads',null,owner)).status,200);
 const rows=(await call('admin/dashboard',null,owner)).data.quotes;
 assert.equal(rows.find(x=>x.id===result.data.id).payload.departuresPerWeek,3);
 assert.equal(rows.find(x=>x.id===result.data.id).payload.returnLoad,'yes');
});
test('loading and unloading coordinates preserve precision, validate ranges and remain private',async()=>{
 const req={company:'GPS customer',email:'gps@example.test',language:'en',origin:'Loading site',destination:'Unloading site',loadingCoordinates:'39.92900070441411, -0.10445717145356245',unloadingCoordinates:' 40.416775 , -3.703790 '};
 for(const bad of ['91, 0','0, -181','NaN, 0','39,929, -0,104','https://maps.app.goo.gl/example','1,2,3'])assert.equal((await call('quotes',{...req,loadingCoordinates:bad})).data.error,'invalid_coordinates');
 assert.equal((await call('quotes',{...req,unloadingCoordinates:'0,181'})).status,400);
 const result=await call('quotes',req);assert.equal(result.status,201);
 const q=(await call('admin/dashboard',null,owner)).data.quotes.find(x=>x.id===result.data.id);
 assert.equal(q.payload.loadingCoordinates,req.loadingCoordinates);
 assert.equal(q.payload.unloadingCoordinates,'40.416775, -3.703790');
 assert.equal((await call('admin/dashboard')).status,401);
});
test('partial loads require positive loading metres and full loads discard stale values',async()=>{
 const req={company:'Partial customer',email:'ldm@example.test',language:'tr',loadType:'ltl',serviceCode:'Parsiyel yük (LTL)'};
 for(const loadingMetres of ['',0,-1,'NaN','Infinity','6m','1,2,3'])assert.equal((await call('quotes',{...req,loadingMetres})).data.error,'invalid_loading_metres');
 const result=await call('quotes',{...req,loadingMetres:'6,5'});assert.equal(result.status,201);
 let q=(await call('admin/dashboard',null,owner)).data.quotes.find(x=>x.id===result.data.id);assert.equal(q.payload.loadType,'ltl');assert.equal(q.payload.loadingMetres,6.5);
 const full=await call('quotes',{...req,serviceCode:'Komple yük (FTL)',loadType:'ftl',loadingMetres:'6.5'});assert.equal(full.status,201);
 q=(await call('admin/dashboard',null,owner)).data.quotes.find(x=>x.id===full.data.id);assert.ok(!('loadingMetres' in q.payload));
 assert.equal((await call('quotes',{...req,loadType:'ftl'})).status,400);
});
test('linked load lifecycle archives, reopens and counts deliveries once without private data leaks',async()=>{
 const before=(await call('stats')).data;
 const l={...load,reference:'FLOW-LOAD-1',customer_code:'ACME-001',carrier_name:'Private Carrier Ltd'};
 const created=await call('admin/load',l,owner);assert.equal(created.status,200);
 const shipment={reference:'FLOW-SHIP-1',load_id:created.data.id,load_revision:1,origin:l.origin,destination:l.destination,eta:'2026-11-01',status:'planned',location:'Madrid',notes:{en:'',es:'',tr:''}};
 const c=await call('admin/shipment',shipment,owner);assert.equal(c.status,200);assert.ok(c.data.accessKey);
 let dash=(await call('admin/dashboard?loadSearch=FLOW-LOAD-1',null,owner)).data;let row=dash.loads[0];assert.equal(row.status,'reserved');assert.equal(row.shipment_id,c.data.id);
 assert.equal((await call('admin/shipment',{...shipment,reference:'FLOW-DUP'},owner)).status,409);
 assert.equal((await call('admin/load',{...l,id:created.data.id,revision:row.revision,status:'archived'},owner)).data.error,'linked_status_managed');
 assert.equal((await call('admin/shipment',{...shipment,id:c.data.id,revision:1,status:'in_transit'},owner)).status,200);
 assert.equal((await call('admin/shipment',{...shipment,id:c.data.id,revision:1,status:'delivered'},owner)).status,409);
 assert.equal((await call('admin/shipment',{...shipment,id:c.data.id,revision:2,status:'delivered'},owner)).status,200);
 let stats=(await call('stats')).data;assert.equal(stats.deliveredShipments,before.deliveredShipments+1);assert.equal(stats.servedCustomers,before.servedCustomers+1);assert.deepEqual(Object.keys(stats).sort(),['activeShipments','deliveredShipments','servedCustomers']);
 dash=(await call('admin/dashboard?loadView=active&loadSearch=FLOW-LOAD-1&shipmentView=active&shipmentSearch=FLOW-SHIP-1',null,owner)).data;assert.equal(dash.loads.length,0);assert.equal(dash.shipments.length,0);
 dash=(await call('admin/dashboard?loadView=archive&loadSearch=FLOW-LOAD-1&shipmentView=archive&shipmentSearch=FLOW-SHIP-1',null,owner)).data;assert.equal(dash.loads[0].status,'closed');assert.equal(dash.shipments.length,1);
 const tracked=await call('track',{reference:shipment.reference,accessKey:c.data.accessKey});assert.equal(tracked.data.shipment.status,'delivered');assert.equal(tracked.data.events.length,3);assert.ok(!JSON.stringify(tracked.data).includes('ACME-001'));assert.ok(!JSON.stringify(tracked.data).includes('Private Carrier'));
 assert.equal((await call('admin/shipment',{...shipment,id:c.data.id,revision:3,status:'delivered'},owner)).status,200);assert.equal((await call('stats')).data.deliveredShipments,stats.deliveredShipments);
 assert.equal((await call('admin/shipment',{...shipment,id:c.data.id,revision:4,status:'delayed'},owner)).status,200);stats=(await call('stats')).data;assert.equal(stats.deliveredShipments,before.deliveredShipments);assert.equal(stats.servedCustomers,before.servedCustomers);
 dash=(await call('admin/dashboard?loadSearch=FLOW-LOAD-1',null,owner)).data;assert.equal(dash.loads[0].status,'in_transit');
 assert.equal((await call('admin/shipment',{...shipment,id:c.data.id,revision:5,load_id:'different'},owner)).data.error,'linked_load_locked');
});
test('server-side archive search, pagination and customer deduplication',async()=>{
 for(let i=0;i<52;i++){const r=await call('admin/load',{...load,reference:'PAGE-'+String(i).padStart(3,'0'),customer_code:'SAME-FIRM',carrier_name:'Search%Carrier',status:'available'},owner);assert.equal(r.status,200)}
 const a=(await call('admin/dashboard?loadSearch=PAGE-&loadPage=1',null,owner)).data,b=(await call('admin/dashboard?loadSearch=PAGE-&loadPage=2',null,owner)).data;assert.equal(a.pagination.load.total,52);assert.equal(a.loads.length,50);assert.equal(b.loads.length,2);assert.ok(!a.loads.some(x=>b.loads.some(y=>y.id===x.id)));
 assert.equal((await call('admin/dashboard?loadSearch=Search%25Carrier',null,owner)).data.pagination.load.total,52);
 const before=(await call('stats')).data;
 for(const [i,l] of a.loads.slice(0,2).entries()){assert.equal((await call('admin/shipment',{reference:'PAGE-SHIP-'+i,load_id:l.id,load_revision:l.revision,origin:l.origin,destination:l.destination,eta:'',status:'delivered',location:'Delivered',notes:{en:'',es:'',tr:''}},owner)).status,200)}
 const after=(await call('stats')).data;assert.equal(after.deliveredShipments,before.deliveredShipments+2);assert.equal(after.servedCustomers,before.servedCustomers+1);
 assert.equal((await call('admin/dashboard?loadView=archive&loadSearch=PAGE-',null,owner)).data.pagination.load.total,2);
});

test('public transport cards expose only approved cities and disappear on delivery',async()=>{
 const c=await call('admin/load',{...load,reference:'PUBLIC-CARD',origin:'Secret loading address',destination:'Secret delivery address',customer_code:'PRIVATE',carrier_name:'PRIVATE CARRIER',public_origin:'Madrid',public_destination:'Baku',origin_country:'ES',destination_country:'AZ'},owner);assert.equal(c.status,200);
 let rows=(await call('active-transports')).data.transports;const card=rows.find(x=>x.id===c.data.id);assert.equal(card.origin,'Madrid');assert.deepEqual(Object.keys(card).sort(),['id','origin','destination','origin_country','destination_country','equipment','status'].sort());assert.ok(!JSON.stringify(rows).includes('Secret'));
 const s={reference:'PUBLIC-TRACK',load_id:c.data.id,load_revision:1,origin:'Secret loading address',destination:'Secret delivery address',status:'planned',eta:'2026-11-01',location:'Private GPS',notes:{en:'Private',es:'Privado',tr:'Özel'}};
 const ship=await call('admin/shipment',s,owner);assert.equal(ship.status,200);assert.equal((await call('active-transports?id='+c.data.id)).data.transports.length,1);
 assert.equal((await call('admin/shipment',{...s,id:ship.data.id,revision:1,status:'delivered'},owner)).status,200);assert.equal((await call('active-transports?id='+c.data.id)).data.transports.length,0);
 const hidden=await call('admin/load',{...load,reference:'NO-CARD'},owner);assert.equal((await call('active-transports?id='+hidden.data.id)).data.transports[0].origin,'');
});

test('draft card remains private until published; clearing cities redacts labels without changing operation count',async()=>{
 const value={...load,reference:'DRAFT-PUBLISH-CARD',status:'draft',public_origin:'Valencia',public_destination:'Berlin'};
 const created=await call('admin/load',value,owner);assert.equal(created.status,200);const id=created.data.id;
 assert.equal((await call('active-transports?id='+id)).data.transports.length,0);
 assert.equal((await call('admin/load',{...value,id,revision:1,status:'available'},owner)).status,200);
 assert.equal((await call('active-transports?id='+id)).data.transports[0].origin,'Valencia');
 assert.equal((await call('admin/load',{...value,id,revision:2,status:'available',public_origin:''},owner)).status,200);
 assert.equal((await call('active-transports?id='+id)).data.transports[0].origin,'');
});

test('one load and two direct shipments share three cards and one consistent counter',async()=>{
 const before=(await call('active-transports')).data;assert.equal(before.transports.length,before.stats.activeShipments);
 const made=await call('admin/load',{...load,reference:'UNIFIED-LOAD',public_origin:'Madrid',public_destination:'Berlin'},owner);assert.equal(made.status,200);
 const base={origin:'PRIVATE ADDRESS',destination:'PRIVATE WAREHOUSE',eta:'2026-11-01',location:'PRIVATE GPS',status:'planned',notes:{en:'Private',es:'Privado',tr:'Özel'}};
 const one=await call('admin/shipment',{...base,reference:'UNIFIED-DIRECT-1',public_origin:'Paris',public_destination:'Ankara'},owner);
 const two=await call('admin/shipment',{...base,reference:'UNIFIED-DIRECT-2'},owner);assert.equal(one.status,200);assert.equal(two.status,200);
 let feed=(await call('active-transports')).data;assert.equal(feed.transports.length,before.transports.length+3);assert.equal(feed.stats.activeShipments,feed.transports.length);assert.equal((await call('stats')).data.activeShipments,feed.transports.length);
 assert.equal(feed.transports.find(x=>x.id===two.data.id).origin,'');assert.ok(!JSON.stringify(feed).includes('PRIVATE ADDRESS'));
 const linked=await call('admin/shipment',{...base,reference:'UNIFIED-LINK',load_id:made.data.id,load_revision:1},owner);assert.equal(linked.status,200);
 feed=(await call('active-transports')).data;assert.equal(feed.transports.length,before.transports.length+3);assert.equal(feed.stats.activeShipments,feed.transports.length);
 await call('admin/shipment',{...base,id:one.data.id,reference:'UNIFIED-DIRECT-1',revision:1,status:'delivered'},owner);
 feed=(await call('active-transports')).data;assert.equal(feed.transports.length,before.transports.length+2);assert.equal(feed.stats.activeShipments,feed.transports.length);
 await call('admin/shipment',{...base,id:linked.data.id,reference:'UNIFIED-LINK',revision:1,status:'delivered'},owner);
 feed=(await call('active-transports')).data;assert.equal(feed.transports.length,before.transports.length+1);assert.equal(feed.stats.activeShipments,feed.transports.length);
});

test('unified job editor creates draft, activates tracking, preserves one job and archives delivery',async()=>{
 const job={reference:'ONE-JOB',origin:'Madrid private address',destination:'Berlin private address',public_origin:'Madrid',public_destination:'Berlin',customer_code:'JOB-CUSTOMER',carrier_name:'Test carrier',origin_country:'ES',destination_country:'DE',equipment:'curtain',weight:'12000',pallets:'20',pickup_date:'2026-11-01',eta:'2026-11-04',tractor_plate:'JOB-TRACTOR',trailer_plate:'JOB-TRAILER',location:'Madrid',status:'draft'};
 assert.equal((await call('admin/jobs')).status,401);assert.equal((await call('admin/job',job)).status,401);assert.equal((await call('admin/job',job,other)).status,403);
 const draft=await call('admin/job',job,owner);assert.equal(draft.status,200);assert.equal(draft.data.accessKey,null);
 let list=await call('admin/jobs?view=draft&search=ONE-JOB',null,owner);assert.equal(list.status,200);assert.equal(list.data.jobs.length,1);let row=list.data.jobs[0];assert.equal(row.shipment_id,null);
 assert.equal((await call('admin/jobs?view=active&search=ONE-JOB',null,owner)).data.jobs.length,0);
 const before=(await call('stats')).data;
 const active=await call('admin/job',{...row,...job,status:'planned'},owner);assert.equal(active.status,200);assert.equal(active.data.accessKey.length,40);
 row=(await call('admin/jobs?view=active&search=ONE-JOB',null,owner)).data.jobs[0];assert.ok(row.shipment_id);assert.equal((await call('stats')).data.activeShipments,before.activeShipments+1);
 const track=await call('track',{reference:active.data.reference,accessKey:active.data.accessKey});assert.equal(track.status,200);
 const delivery=await call('admin/job',{...row,status:'delivered'},owner);assert.equal(delivery.status,200);assert.equal(delivery.data.accessKey,null);
 const stale=await call('admin/job',{...row,status:'in_transit'},owner);assert.equal(stale.status,409);
 assert.equal((await call('admin/jobs?view=active&search=ONE-JOB',null,owner)).data.jobs.length,0);
 row=(await call('admin/jobs?view=archive&search=ONE-JOB',null,owner)).data.jobs[0];assert.equal(row.status,'delivered');assert.equal((await call('stats')).data.deliveredShipments,before.deliveredShipments+1);assert.equal((await call('stats')).data.servedCustomers,before.servedCustomers+1);
 assert.equal((await call('track',{reference:active.data.reference,accessKey:active.data.accessKey})).data.shipment.status,'delivered');
 assert.equal((await call('admin/job',{...row,status:'draft'},owner)).data.error,'job_tracking_exists');
 assert.equal((await call('admin/job',{...row,reference:'CHANGED'},owner)).data.error,'job_reference_locked');
 assert.equal((await call('admin/job',{...row,status:'delayed'},owner)).status,200);
 assert.equal((await call('stats')).data.deliveredShipments,before.deliveredShipments);
});

test('legacy direct shipment becomes one editable job without losing its key, history or card identity',async()=>{
 const old={reference:'LEGACY-JOB',origin:'Old private address',destination:'Destination',eta:'',status:'in_transit',location:'On route',notes:{en:'Original event',es:'Evento original',tr:'Eski kayıt'}};
 const created=await call('admin/shipment',old,owner);assert.equal(created.status,200);
 let row=(await call('admin/jobs?view=all&search=LEGACY-JOB',null,owner)).data.jobs[0];assert.equal(row.kind,'shipment');const before=(await call('stats')).data;
 const saved=await call('admin/job',{...row,customer_code:'LEGACY-CUSTOMER',carrier_name:'Legacy carrier',public_origin:'Paris',public_destination:'Madrid',equipment:'curtain',status:'delivered'},owner);assert.equal(saved.status,200);assert.equal(saved.data.id,created.data.id);assert.equal(saved.data.accessKey,null);
 const list=(await call('admin/jobs?view=all&search=LEGACY-JOB',null,owner)).data.jobs;assert.equal(list.length,1);row=list[0];assert.equal(row.kind,'load');assert.equal(row.shipment_id,created.data.id);assert.equal(row.customer_code,'LEGACY-CUSTOMER');
 const tracked=(await call('track',{reference:old.reference,accessKey:created.data.accessKey})).data;assert.equal(tracked.shipment.status,'delivered');assert.equal(tracked.events.length,2);assert.ok(tracked.events.some(x=>x.notes.en==='Original event'));
 assert.equal((await call('stats')).data.servedCustomers,before.servedCustomers+1);
});

test('failed unified save rolls back load insert and does not duplicate an existing tracking reference',async()=>{
 const old={reference:'ROLLBACK-REFERENCE',origin:'A',destination:'B',eta:'',status:'planned',location:'',notes:{en:'',es:'',tr:''}};await call('admin/shipment',old,owner);
 const job={...old,public_origin:'A',public_destination:'B',customer_code:'',carrier_name:'',origin_country:'',destination_country:'',equipment:'',weight:'',pallets:'',pickup_date:''};
 const before=(await call('admin/jobs?view=all&search=ROLLBACK-REFERENCE',null,owner)).data;
 const result=await call('admin/job',job,owner);assert.equal(result.status,409);
 const after=(await call('admin/jobs?view=all&search=ROLLBACK-REFERENCE',null,owner)).data;assert.equal(after.jobs.length,before.jobs.length);assert.equal(after.jobs[0].kind,'shipment');
});

test('private immutable job PDFs keep customer and carrier prices separate',async()=>{
 const objects=new Map();env.BUCKET={put:async(k,v)=>objects.set(k,new Uint8Array(v)),get:async k=>objects.has(k)?{body:objects.get(k)}:null,delete:async k=>objects.delete(k)};
 const create=await call('admin/job',{...load,reference:'PDF-JOB',status:'planned',customer_code:'HIDDEN-CUSTOMER-CODE',carrier_name:'SECRET-CARRIER'},owner);assert.equal(create.status,200);
 const ctx=(await call('admin/documents?job_id='+create.data.id,null,owner)).data;assert.equal(ctx.documents.length,0);
 const b={id:crypto.randomUUID(),job_id:create.data.id,load_revision:ctx.job.load_revision,shipment_revision:ctx.job.shipment_revision,type:'customer',language:'tr',mode:'draft',recipient_name:'Test Alıcı Şirketi',origin:'Valencia',destination:'İstanbul',loading_gps:'39.92900070441411, -0.10445717145356245',load_type:'ltl',loading_metres:6.5,currency:'EUR',amount:'2250.00',carrier_price:1800,margin:450};
 for(const p of ['admin/documents?job_id='+create.data.id,'admin/document/pdf?id=missing']){assert.equal((await call(p)).status,401);assert.equal((await call(p,null,other)).status,403)}
 assert.equal((await call('admin/document',b)).status,401);assert.equal((await call('admin/document',b,other)).status,403);assert.equal((await call('admin/document',b,owner,'https://evil.test')).status,403);
 assert.equal((await call('admin/document',{...b,mode:'ready'},owner)).data.error,'doc_ready_fields');assert.equal((await call('admin/document',{...b,loading_metres:0},owner)).data.error,'doc_ldm');
 const r=await call('admin/document',b,owner);assert.equal(r.status,200);assert.equal((await call('admin/document',b,owner)).data.id,r.data.id);assert.equal(objects.size,1);
 let result=(await call('admin/documents?job_id='+create.data.id,null,owner)).data;let snap=result.documents[0].snapshot;assert.equal(snap.amount,2250);assert.equal(snap.loading_gps,b.loading_gps);for(const k of ['carrier_price','margin','carrier_name','customer_code','access_hash'])assert.ok(!(k in snap));
 const raw=await handleApi(new Request('https://sdes.test/api/admin/document/pdf?id='+r.data.id,{headers:owner}),env);assert.equal(raw.status,200);assert.equal(raw.headers.get('Content-Type'),'application/pdf');assert.match(raw.headers.get('Content-Disposition'),/^attachment; filename="SDES-C-/);assert.equal(new TextDecoder().decode(new Uint8Array(await raw.arrayBuffer()).slice(0,5)),'%PDF-');
 assert.equal((await call('media/private-documents/any.pdf')).status,404);
 const carrier=await call('admin/document',{...b,id:crypto.randomUUID(),type:'carrier',amount:'1800',language:'es',recipient_name:'Test Carrier',load_type:'ftl'},owner);assert.equal(carrier.status,200);
 result=(await call('admin/documents?job_id='+create.data.id,null,owner)).data;assert.equal(result.documents.length,2);snap=result.documents.find(d=>d.type==='carrier').snapshot;assert.equal(snap.amount,1800);assert.equal(snap.loading_metres,null);
 const row=ctx.job;assert.equal((await call('admin/job',{...row,origin:'Changed origin',status:'in_transit'},owner)).status,200);
 assert.equal((await call('admin/document',{...b,id:crypto.randomUUID()},owner)).data.error,'doc_conflict');result=(await call('admin/documents?job_id='+create.data.id,null,owner)).data;assert.equal(result.documents.find(d=>d.id===r.data.id).snapshot.origin,'Valencia');assert.equal(result.job.origin,'Changed origin');
 assert.equal((await call('admin/document',{...b,id:r.data.id,type:'carrier'},owner)).status,409);
});

test('enquiry pipeline preserves original details, protects notes and guards concurrent updates',async()=>{
 const id=crypto.randomUUID(),original={origin:'Private Madrid warehouse',destination:'Private Istanbul address',loadingCoordinates:'39.92900070441411, -0.10445717145356245',notes:'Original customer message'};
 await env.DB.prepare('INSERT INTO quotes (id,company,email,language,payload,status,ip_hash,created_at) VALUES (?,?,?,?,?,?,?,?)').bind(id,'CRM 100% Company','crm@example.test','tr',JSON.stringify(original),'new','crm-test','2026-10-20T09:00:00Z').run();
 assert.equal((await call('admin/quotes')).status,401);assert.equal((await call('admin/quotes',null,other)).status,403);
 let d=(await call('admin/quotes?search=CRM%20100%25',null,owner)).data;assert.equal(d.quotes.length,1);assert.equal(d.quotes[0].revision,1);assert.equal(d.quotes[0].internal_notes,'');assert.equal(d.timeZone,'Europe/Madrid');assert.match(d.today,/^\d{4}-\d{2}-\d{2}$/);
 const change={id,revision:1,status:'contacted',follow_up_date:d.today,internal_notes:'Private commercial note <script>never execute</script>'};
 assert.equal((await call('admin/quote',change,owner,'https://evil.test')).status,403);
 assert.equal((await call('admin/quote',{...change,follow_up_date:'2026-02-30'},owner)).status,400);
 assert.equal((await call('admin/quote',{...change,revision:undefined},owner)).status,409);
 assert.equal((await call('admin/quote',change,owner)).status,200);
 assert.equal((await call('admin/quote',{...change,status:'lost'},owner)).status,409);
 d=(await call('admin/quotes?stage=open&follow=today&search=CRM%20100%25',null,owner)).data;assert.equal(d.quotes.length,1);assert.equal(d.quotes[0].internal_notes,change.internal_notes);assert.deepEqual(d.quotes[0].payload,original);assert.ok(d.due.today>=1);
 assert.equal((await call('admin/quote',{...change,revision:2,status:'quoted'},owner)).status,200);
 assert.equal((await call('admin/quote',{...change,revision:3,status:'won'},owner)).status,200);
 d=(await call('admin/quotes?stage=open&search=CRM%20100%25',null,owner)).data;assert.equal(d.quotes.length,0);
 d=(await call('admin/quotes?stage=won&search=CRM%20100%25',null,owner)).data;assert.equal(d.quotes.length,1);assert.equal(d.quotes[0].revision,4);assert.equal(d.quotes[0].internal_notes,change.internal_notes);
 assert.equal((await call('admin/quote',{...change,revision:4,status:'closed'},owner)).status,400);
 assert.equal((await call('admin/quote',{...change,revision:4,status:'new',follow_up_date:'2000-01-01'},owner)).status,200);
 d=(await call('admin/quotes?follow=overdue&search=CRM%20100%25',null,owner)).data;assert.equal(d.quotes.length,1);assert.ok(d.due.overdue>=1);
 const publicFeed=JSON.stringify((await call('active-transports')).data);assert.ok(!publicFeed.includes(change.internal_notes));assert.equal((await call('quotes?search=CRM')).status,404);
});

test('enquiry archive does not infer old closed outcomes and paginates beyond 200',async()=>{
 const batch=[];for(let i=0;i<205;i++)batch.push(env.DB.prepare('INSERT INTO quotes (id,company,email,language,payload,status,ip_hash,created_at) VALUES (?,?,?,?,?,?,?,?)').bind('crm-page-'+i,'CRM Paging '+i,'paging@example.test','en','{}',i===0?'closed':'lost','paging','2026-10-01T00:00:00Z'));await env.DB.batch(batch);
 let d=(await call('admin/quotes?stage=all&search=CRM%20Paging&page=5',null,owner)).data;assert.equal(d.pagination.total,205);assert.equal(d.pagination.pages,5);assert.equal(d.quotes.length,5);
 d=(await call('admin/quotes?stage=closed&search=CRM%20Paging',null,owner)).data;assert.equal(d.quotes.length,1);assert.equal(d.quotes[0].status,'closed');
 assert.equal((await call('admin/quote',{id:d.quotes[0].id,revision:1,status:'won',internal_notes:'Outcome verified'},owner)).status,200);
 d=(await call('admin/quotes?stage=closed&search=CRM%20Paging',null,owner)).data;assert.equal(d.quotes.length,0);
 assert.equal((await call('admin/quotes?stage=unknown',null,owner)).status,400);
 assert.equal((await call('admin/quotes?follow=unknown',null,owner)).status,400);
});

test('won enquiries convert once into a private editable draft with original GPS and cargo snapshot',async()=>{
 const id=crypto.randomUUID(),payload={origin:'Private warehouse '+ 'address '.repeat(25),destination:'Private Istanbul depot',loadingCoordinates:'39.92900070441411, -0.10445717145356245',unloadingCoordinates:'41.0082, 28.9784',loadType:'ltl',loadingMetres:6.5,weight:'12 tonnes',volume:'16 mixed pallets',notes:'Fragile goods; keep dry',shipmentFrequency:'regular',departuresPerWeek:3};
 await env.DB.prepare('INSERT INTO quotes (id,company,email,language,payload,status,ip_hash,created_at) VALUES (?,?,?,?,?,?,?,?)').bind(id,'Conversion Customer','conversion@example.test','tr',JSON.stringify(payload),'new','conversion','2026-10-23T09:00:00Z').run();
 assert.equal((await call('admin/quote-job?quote_id='+id)).status,401);assert.equal((await call('admin/quote-job?quote_id='+id,null,other)).status,403);
 assert.equal((await call('admin/quote-job?quote_id='+id,null,owner)).data.error,'quote_not_won');
 const b={...load,reference:'CONVERT-TEST',status:'draft',source_quote_id:id,quote_revision:1,origin:payload.origin,destination:payload.destination,customer_name:'Conversion Customer',customer_email:'conversion@example.test',loading_gps:payload.loadingCoordinates,unloading_gps:payload.unloadingCoordinates,load_type:'ltl',loading_metres:6.5,cargo_description:payload.notes,weight:'',pickup_date:''};
 assert.equal((await call('admin/job',b,owner)).data.error,'quote_not_won');
 assert.equal((await call('admin/quote',{id,revision:1,status:'won'},owner)).status,200);
 assert.equal((await call('admin/job',b,owner)).data.error,'quote_conflict');
 const preview=(await call('admin/quote-job?quote_id='+id,null,owner)).data;assert.equal(preview.quote.revision,2);assert.equal(preview.quote.payload.weight,'12 tonnes');assert.equal(preview.job,undefined);
 assert.equal((await call('admin/job',{...b,quote_revision:2,loading_gps:'91,0'},owner)).data.error,'invalid_coordinates');
 const before=(await call('stats')).data,created=await call('admin/job',{...b,quote_revision:2},owner);assert.equal(created.status,200);assert.equal(created.data.accessKey,null);
 assert.deepEqual((await call('stats')).data,before);
 assert.equal((await call('admin/job',{...b,reference:'DUP-CONVERT',quote_revision:2},owner)).data.error,'quote_already_converted');
 let row=(await call('admin/quote-job?quote_id='+id,null,owner)).data.job;assert.equal(row.id,created.data.id);assert.equal(row.status,'draft');assert.equal(row.source_quote_id,id);assert.equal(row.loading_gps,payload.loadingCoordinates);assert.equal(row.loading_metres,6.5);assert.equal(row.weight,null);assert.deepEqual(row.source_request.payload,payload);
 const q=(await call('admin/quotes?stage=won&search=Conversion%20Customer',null,owner)).data.quotes[0];assert.equal(q.job_id,row.id);assert.equal(q.job_reference,'CONVERT-TEST');assert.equal(q.revision,3);
 let doc=(await call('admin/documents?job_id='+row.id,null,owner)).data;assert.equal(doc.job.customer_email,'conversion@example.test');assert.equal(doc.job.loading_metres,6.5);
 assert.equal((await call('admin/job',{...row,status:'planned',weight:12000,customer_code:'CONV-001',public_origin:'Valencia',public_destination:'Istanbul'},owner)).status,200);
 row=(await call('admin/quote-job?quote_id='+id,null,owner)).data.job;assert.equal(row.status,'planned');assert.ok(row.shipment_id);assert.equal(row.weight,12000);assert.deepEqual(row.source_request.payload,payload);
 const publicRecord=(await call('active-transports?id='+row.id)).data;const raw=JSON.stringify(publicRecord);for(const privateValue of ['conversion@example.test',payload.origin,payload.loadingCoordinates,'12 tonnes','Fragile goods','CONV-001'])assert.ok(!raw.includes(privateValue),privateValue);
 assert.equal((await call('admin/job',{...row,source_quote_id:'different-quote'},owner)).status,400);
});

test('failed conversion rolls back and cannot change original enquiry or create a partial job',async()=>{
 const id=crypto.randomUUID();await env.DB.prepare('INSERT INTO quotes (id,company,email,language,payload,status,ip_hash,created_at) VALUES (?,?,?,?,?,?,?,?)').bind(id,'Rollback Conversion','rollback@example.test','en','{}','won','conversion','2026-10-23T09:00:00Z').run();
 const b={...load,reference:'TEST-LOAD',status:'planned',source_quote_id:id,quote_revision:1};
 assert.equal((await call('admin/job',b,owner)).status,409);
 const q=await env.DB.prepare('SELECT revision FROM quotes WHERE id=?').bind(id).first();assert.equal(q.revision,1);
 assert.equal(await env.DB.prepare('SELECT id FROM loads WHERE source_quote_id=?').bind(id).first(),null);
 const response=await call('admin/job',{...b,reference:'VALID-CONVERT-AFTER-FAIL'},owner);assert.equal(response.status,200);assert.ok(response.data.accessKey);
});

test('enquiry emails trim pasted edge whitespace, preserve aliases and reject malformed addresses',async()=>{
 const local={DB:database()};
 for(const [email,status] of [['\u00a0Test+route@example.com\u200B',201],['test@@example.com',400],['first last@example.com',400],['',400],['test@example',400]]){
  const r=await handleApi(new Request('https://sdes.test/api/quotes',{method:'POST',headers:{origin:'https://sdes.test','content-type':'application/json'},body:JSON.stringify({company:'Email test',email,language:'tr'})}),local);
  assert.equal(r.status,status);const data=await r.json();if(status===400)assert.equal(data.error,'invalid_email');else {const q=await local.DB.prepare('SELECT email FROM quotes WHERE id=?').bind(data.id).first();assert.equal(q.email,'Test+route@example.com')}
 }
});

test('customer history groups exact contacts, includes archives, paginates and stays owner-only',async()=>{
 const db=database(),local={DB:db,ADMIN_BOOTSTRAP_EMAIL:'owner@example.test'};
 const request=async(path,user=owner)=>{const r=await handleApi(new Request('https://sdes.test/api/'+path,{headers:user}),local);return {status:r.status,data:await r.json()}};
 assert.equal((await request('admin/customers',{})).status,401);
 assert.equal((await request('admin/customers',other)).status,403);
 for(let i=0;i<52;i++)await db.prepare("INSERT INTO quotes(id,company,email,language,payload,status,created_at,ip_hash) VALUES (?,?,?,?,?,?,?,'test')").bind('history-'+i,'Same company',i<51?(i%2?'CONTACT@example.test':'contact@example.test'):'different@example.test','en',JSON.stringify({origin:'Madrid',destination:'Paris'}),'quoted','2026-10-24T00:00:00Z').run();
 const create=await handleApi(new Request('https://sdes.test/api/admin/job',{method:'POST',headers:{...owner,origin:'https://sdes.test','content-type':'application/json'},body:JSON.stringify({reference:'HISTORY-JOB',status:'draft',origin:'A',destination:'B',customer_email:'contact@example.test',customer_name:'Same company'})}),local);assert.equal(create.status,200);const job=await create.json();
 let list=await request('admin/customers');assert.equal(list.data.customers.length,2);const c=list.data.customers.find(x=>x.customer_key==='email:contact@example.test');assert.equal(c.enquiries,51);assert.equal(c.jobs,1);
 let history=(await request('admin/customers?key=email%3Acontact%40example.test')).data;assert.equal(history.pagination.total,52);assert.equal(history.activity.length,50);assert.equal(history.pagination.pages,2);
 history=(await request('admin/customers?key=email%3Acontact%40example.test&page=2')).data;assert.equal(history.activity.length,2);
 assert.equal((await request('admin/customers?search=different')).data.customers.length,1);
 assert.equal((await request('admin/customers?search=%25')).data.customers.length,0);
 assert.equal((await request('admin/job-detail?id='+job.id,{})).status,401);
 assert.equal((await request('admin/job-detail?id='+job.id,other)).status,403);
 assert.equal((await request('admin/job-detail?id='+job.id)).data.job.customer_email,'contact@example.test');
 await db.prepare("UPDATE loads SET status='closed' WHERE id=?").bind(job.id).run();
 assert.equal((await request('admin/customers?key=email%3Acontact%40example.test')).data.summary.jobs,1);
});

test('regular routes persist privately, validate plans, protect concurrent edits and never create shipments',async()=>{
 const route={company:'Route customer',email:'\u00a0route@example.test\u00a0',customer_code:'RT-01',origin:'Frankfurt depot',destination:'Madrid depot',loading_gps:'50.110924, 8.682127',unloading_gps:'40.416775, -3.703790',departures_per_week:2,start_date:'2026-11-01',end_date:'2027-01-31',equipment:'curtain',load_type:'ltl',loading_metres:'6,5',return_load:'yes',schedule_notes:'Monday, Thursday',notes:'Private route instructions',status:'planning'};
 for(const path of ['admin/regular-routes','admin/regular-route']){assert.equal((await call(path,path.endsWith('routes')?null:route)).status,401);assert.equal((await call(path,path.endsWith('routes')?null:route,other)).status,403)}
 const stats=(await call('stats')).data;
 const c=await call('admin/regular-route',route,owner);assert.equal(c.status,200);let record=(await call('admin/regular-routes?search=RT-01',null,owner)).data.routes.find(x=>x.id===c.data.id);assert.equal(record.email,'route@example.test');assert.equal(record.loading_metres,6.5);assert.equal(record.loading_gps,route.loading_gps);
 assert.equal((await call('admin/regular-route',{...route,id:c.data.id,revision:1,status:'active'},owner)).status,200);
 assert.equal((await call('admin/regular-route',{...route,id:c.data.id,revision:1,status:'archived'},owner)).status,409);
 assert.equal((await call('admin/regular-route',{...route,id:c.data.id,revision:2,status:'archived',load_type:'ftl'},owner)).status,200);
 assert.equal((await call('admin/regular-routes',null,owner)).data.routes.some(x=>x.id===c.data.id),false);
 record=(await call('admin/regular-routes?status=archived',null,owner)).data.routes.find(x=>x.id===c.data.id);assert.equal(record.loading_metres,null);assert.equal(record.notes,route.notes);
 assert.deepEqual((await call('stats')).data,stats);
 assert.equal((await call('admin/regular-route',route,owner,'https://evil.test')).status,403);
 for(const patch of [{email:'wrong'}, {departures_per_week:0},{departures_per_week:1.5},{end_date:'2026-10-31'},{start_date:'2026-02-30'},{loading_gps:'91, 0'},{loading_metres:0},{loading_metres:31},{status:'unknown'}])assert.equal((await call('admin/regular-route',{...route,...patch},owner)).status,400,JSON.stringify(patch));
 assert.equal((await call('admin/regular-routes?status=unknown',null,owner)).status,400);
 assert.equal((await call('admin/regular-routes?status=all&search=%25',null,owner)).data.pagination.total,0);
});

test('editorial drafts preserve incomplete translations; publication, archive and stale saves are guarded',async()=>{
 const a={slug:'editorial-workflow-test',revision:0,status:'draft',category:'analysis',published_at:'2026-10-25',image:'',illustration:false,sources:[],en:{title:'Draft title',intro:'',body:'',alt:''},es:{title:'',intro:'',body:'',alt:''},tr:{title:'',intro:'',body:'',alt:''}};
 assert.equal((await call('admin/article',a,owner)).status,200);
 assert.equal((await call('articles?slug='+a.slug)).data.articles.length,0);
 assert.equal((await call('admin/articles?slug='+a.slug,null,owner)).data.articles[0].en.title,'Draft title');
 assert.equal((await call('admin/article',{...a,revision:1,status:'published'},owner)).data.error,'image_required');
 assert.equal((await call('admin/article',{...a,revision:1,status:'published',image:'/assets/blog-efti.webp'},owner)).data.error,'all_languages_required');
 for(const d of ['2026-99-99','2026-02-30','not-a-date'])assert.equal((await call('admin/article',{...a,revision:1,published_at:d},owner)).status,400);
 a.image='/assets/blog-efti.webp';a.status='published';a.revision=1;for(const l of ['en','es','tr'])a[l]={title:l+' title',intro:l+' intro',body:l+' body',alt:l+' image'};
 assert.equal((await call('admin/article',a,owner)).status,200);
 assert.equal((await call('articles?slug='+a.slug)).data.articles.length,1);
 assert.equal((await call('admin/article',{...a,status:'archived'},owner)).status,409);
 assert.equal((await call('admin/article',{...a,revision:2,status:'archived'},owner)).status,200);
 assert.equal((await call('articles?slug='+a.slug)).data.articles.length,0);
 assert.equal((await call('admin/articles?slug='+a.slug,null,owner)).data.articles[0].tr.body,'tr body');
});

test('CSV preview and commit are private, atomic, duplicate-safe drafts with no public side effects',async()=>{
 const {csvColumns,csvText,parseJobCSV}=await import('../lib/job-csv.mjs'),db=database(),local={DB:db,ADMIN_BOOTSTRAP_EMAIL:'owner@example.test'};
 const request=async(path,data,user=owner,origin='https://sdes.test')=>{const r=await handleApi(new Request('https://sdes.test/api/'+path,{method:data?'POST':'GET',headers:{...user,origin,'content-type':'application/json'},body:data?JSON.stringify(data):undefined}),local);return {status:r.status,data:await r.json()}};
 const fixture=(items)=>csvText([csvColumns,...items.map(x=>csvColumns.map(k=>x[k]??''))]);const row={reference:'CSV-001',origin:'Madrid; depot',destination:'Frankfurt',customer_name:'A "Company"',customer_email:'cargo@example.test',loading_gps:'39.92900070441411, -0.10445717145356245',load_type:'ltl',loading_metres:'6,5',weight:'1000',pallets:'5',cargo_description:'Line one\nLine two',pickup_date:'2026-11-01'};const csv=fixture([row,{...row,reference:'CSV-002'}]);
 assert.equal(parseJobCSV(csv,(e)=>{throw Error(e)})[0].cargo_description,row.cargo_description);
 assert.equal((await request('admin/jobs-import',{csv,action:'preview'},{})).status,401);
 assert.equal((await request('admin/jobs-import',{csv,action:'commit'},other)).status,403);
 assert.equal((await request('admin/jobs-import',{csv,action:'commit'},owner,'https://evil.test')).status,403);
 let result=await request('admin/jobs-import',{csv,action:'preview'});assert.equal(result.data.valid,true);assert.equal(result.data.rows[0].loading_metres,6.5);assert.equal((await db.prepare('SELECT COUNT(*) AS n FROM loads').first()).n,0);
 const bad=await request('admin/jobs-import',{csv:fixture([row,{...row,reference:'CSV-BAD',pallets:'2.5'}]),action:'commit'});assert.equal(bad.data.valid,false);assert.equal(bad.data.errors[0].row,3);assert.equal((await db.prepare('SELECT COUNT(*) AS n FROM loads').first()).n,0);
 const originalBatch=db.batch.bind(db);db.batch=qs=>originalBatch([...qs,qs[0]]);assert.equal((await request('admin/jobs-import',{csv,action:'commit'})).status,409);assert.equal((await db.prepare('SELECT COUNT(*) AS n FROM loads').first()).n,0);db.batch=originalBatch;
 result=await request('admin/jobs-import',{csv,action:'commit'});assert.equal(result.data.committed,true);assert.equal(result.data.total,2);assert.equal((await db.prepare('SELECT COUNT(*) AS n FROM shipments').first()).n,0);
 const record=await db.prepare('SELECT * FROM loads WHERE reference=?').bind('CSV-001').first();assert.equal(record.status,'draft');assert.equal(record.public_origin,'');assert.equal(JSON.parse(record.intake).loading_gps,row.loading_gps);
 result=await request('admin/jobs-import',{csv,action:'commit'});assert.equal(result.data.valid,false);assert.equal(result.data.errors[0].error,'duplicate_reference');assert.equal((await db.prepare('SELECT COUNT(*) AS n FROM loads').first()).n,2);
 assert.equal((await request('active-transports',null,{})).data.transports.length,0);
 for(const path of ['admin/jobs-export','admin/jobs-template']){assert.equal((await request(path,null,{})).status,401);assert.equal((await request(path,null,other)).status,403)}
 const exported=await handleApi(new Request('https://sdes.test/api/admin/jobs-export?view=draft',{headers:owner}),local),text=await exported.text();assert.equal(exported.status,200);assert.ok(text.includes('CSV-001'));assert.ok(!text.includes('access_hash'));assert.ok(!text.includes('accessKey'));assert.ok(!text.includes('tracking_reference'));assert.ok(text.includes(row.loading_gps));assert.ok(csvText([['=HYPERLINK("bad")','+SUM(A1)','@A1','-1']]).includes('"\'=HYPERLINK'));
 assert.equal((await request('admin/jobs-import',{csv:fixture(Array.from({length:51},(_,i)=>({...row,reference:'LIMIT-'+i}))),action:'preview'})).data.error,'csv_limit');
 for(const [text,error]of [[csvText([csvColumns]),'csv_empty'],['x;y\na;b','csv_headers'],[csv+'"unfinished','csv_format']])assert.equal((await request('admin/jobs-import',{csv:text,action:'preview'})).data.error,error);
});

test('job finance uses exact cents, isolated currencies, guarded audit history and private access',async()=>{
 const db=database(),local={DB:db,ADMIN_BOOTSTRAP_EMAIL:'owner@example.test'};
 const request=async(path,data,user=owner,origin='https://sdes.test')=>{const r=await handleApi(new Request('https://sdes.test/api/'+path,{method:data?'POST':'GET',headers:{...user,origin,'content-type':'application/json'},body:data?JSON.stringify(data):undefined}),local);return {status:r.status,data:await r.json()}};
 const j=await request('admin/job',{reference:'FIN-001',status:'planned',origin:'Madrid',destination:'Paris',customer_name:'Finance customer',public_origin:'Madrid',public_destination:'Paris'});assert.equal(j.status,200);
 const base={job_id:j.data.id,revision:0,sale_currency:'EUR',purchase_currency:'EUR',sale_amount:'1000.10',purchase_amount:'800,05',received_amount:'100.01',paid_amount:'200.02',receivable_due:'2020-01-01',payable_due:'2020-01-01',customer_document:'INV-CUSTOMER',carrier_document:'INV-CARRIER',notes:'SECRET-FINANCE-NOTE'};
 assert.equal((await request('admin/finances',null,{})).status,401);assert.equal((await request('admin/finance?job_id='+j.data.id,null,other)).status,403);assert.equal((await request('admin/finance',base,{})).status,401);assert.equal((await request('admin/finance',base,other)).status,403);assert.equal((await request('admin/finance',base,owner,'https://evil.test')).status,403);
 assert.equal((await request('admin/finance',base)).status,200);
 let detail=(await request('admin/finance?job_id='+j.data.id)).data;assert.equal(detail.finance.sale_cents,100010);assert.equal(detail.finance.purchase_cents,80005);assert.equal(detail.finance.receivable_cents,90009);assert.equal(detail.finance.payable_cents,60003);assert.equal(detail.finance.difference_cents,20005);assert.equal(detail.history.length,1);
 assert.equal((await request('admin/finance',base)).status,409);
 assert.equal((await request('admin/finances?view=overdue')).data.pagination.total,1);
 for(const [patch,error]of [[{sale_amount:'1.234'},'finance_amount'],[{received_amount:'1001'},'finance_overpayment'],[{sale_amount:'',purchase_amount:''},'finance_required'],[{purchase_currency:'TRY'},'finance_currency_locked'],[{sale_amount:'-1'},'finance_amount']])assert.equal((await request('admin/finance',{...base,revision:1,...patch})).data.error,error);
 const batch=db.batch.bind(db);db.batch=qs=>batch([...qs,qs[1]]);assert.equal((await request('admin/finance',{...base,revision:1,notes:'should roll back'})).status,409);db.batch=batch;
 detail=(await request('admin/finance?job_id='+j.data.id)).data;assert.equal(detail.finance.revision,1);assert.equal(detail.finance.notes,base.notes);assert.equal(detail.history.length,1);
 assert.equal((await request('admin/finance',{...base,revision:1,received_amount:'1000.10',paid_amount:'800.05'})).status,200);assert.equal((await request('admin/finances?view=settled')).data.pagination.total,1);assert.equal((await request('admin/finances?view=open')).data.pagination.total,0);
 detail=(await request('admin/finance?job_id='+j.data.id)).data;assert.equal(detail.history.length,2);assert.equal(detail.history[1].snapshot.received_cents,10001);
 const j2=await request('admin/job',{reference:'FIN-002',status:'draft',origin:'A',destination:'B'});
 assert.equal((await request('admin/finance',{...base,job_id:j2.data.id,sale_currency:'USD',purchase_currency:'TRY',sale_amount:'500',purchase_amount:'10000',received_amount:'0',paid_amount:'0'})).status,200);
 detail=(await request('admin/finance?job_id='+j2.data.id)).data;assert.equal(detail.finance.difference_cents,null);
 const report=(await request('admin/finances')).data;assert.deepEqual(report.totals.map(x=>x.currency),['EUR','TRY','USD']);assert.equal(report.totals.find(x=>x.currency==='USD').sale,50000);assert.equal(report.totals.find(x=>x.currency==='TRY').purchase,1000000);
 assert.equal((await request('admin/finances?search=FIN-002')).data.pagination.total,1);
 const publicResult=JSON.stringify((await request('active-transports',null,{})).data);for(const secret of [base.notes,base.customer_document,'sale_cents','paid_cents'])assert.ok(!publicResult.includes(secret));
 assert.equal((await request('admin/finance',{...base,job_id:'nonexistent'})).status,404);
});

test('draft planning fields survive reopen, clearing, archive and activation without premature tracking',async()=>{
 const fields={eta:'2026-11-15',location:'Private planning location',tractor_plate:'PRIVATE-TRACTOR',trailer_plate:'PRIVATE-TRAILER'};
 const initial={reference:'DRAFT-PLANNING-REGRESSION',origin:'Madrid private depot',destination:'Frankfurt private depot',status:'draft',...fields};
 const before=(await call('stats')).data;
 const created=await call('admin/job',initial,owner);assert.equal(created.status,200);assert.equal(created.data.accessKey,null);assert.equal(created.data.shipment_id,null);
 const list=async view=>(await call('admin/jobs?view='+view+'&search='+initial.reference,null,owner)).data.jobs[0];
 let row=await list('draft');for(const [k,v] of Object.entries(fields))assert.equal(row[k],v,'draft list '+k);
 let detail=(await call('admin/job-detail?id='+row.id,null,owner)).data.job;for(const [k,v] of Object.entries(fields))assert.equal(detail[k],v,'draft detail '+k);
 assert.deepEqual((await call('stats')).data,before);assert.equal((await env.DB.prepare('SELECT COUNT(*) AS n FROM shipments WHERE load_id=?').bind(row.id).first()).n,0);
 assert.equal((await call('admin/job',{...row,eta:'',tractor_plate:''},owner)).status,200);
 assert.equal((await call('admin/job',{...row,trailer_plate:'STALE'},owner)).status,409);
 row=await list('draft');assert.equal(row.eta,'');assert.equal(row.tractor_plate,'');assert.equal(row.trailer_plate,fields.trailer_plate);
 assert.equal((await call('admin/job',{...row,...fields,status:'archived'},owner)).status,200);row=await list('archive');assert.equal(row.eta,fields.eta);
 assert.equal((await call('admin/job',{...row,status:'draft'},owner)).status,200);row=await list('draft');
 const active=await call('admin/job',{...row,status:'planned'},owner);assert.equal(active.status,200);assert.ok(active.data.accessKey);
 row=await list('active');for(const [k,v] of Object.entries(fields))assert.equal(row[k],v,'activated '+k);
 assert.equal(row.planning,undefined);assert.equal((await env.DB.prepare('SELECT COUNT(*) AS n FROM shipments WHERE load_id=?').bind(row.id).first()).n,1);
 const tracked=(await call('track',{reference:initial.reference,accessKey:active.data.accessKey})).data.shipment;for(const [k,v] of Object.entries(fields))assert.equal(tracked[k],v);
 assert.equal((await call('admin/job',{...row,eta:'',tractor_plate:'',trailer_plate:'',location:''},owner)).status,200);row=await list('active');for(const k of Object.keys(fields))assert.equal(row[k],'','active clearing '+k);
 const publicData=JSON.stringify((await call('active-transports')).data);for(const v of Object.values(fields))assert.ok(!publicData.includes(v));
});
test('quote full addresses retain multiline values up to 800 characters',async()=>{
 const local={DB:database(),ADMIN_BOOTSTRAP_EMAIL:'owner@example.test'};
 const address='Example warehouse\n'+ 'A'.repeat(782);
 const request=body=>handleApi(new Request('https://sdes.test/api/quotes',{method:'POST',headers:{origin:'https://sdes.test','content-type':'application/json'},body:JSON.stringify(body)}),local);
 const payload={company:'Address test',email:'address@example.test',language:'en',origin:address,destination:address};
 const response=await request(payload);assert.equal(response.status,201);const {id}=await response.json();
 const row=await local.DB.prepare('SELECT payload FROM quotes WHERE id=?').bind(id).first();assert.equal(JSON.parse(row.payload).origin,address);assert.equal(JSON.parse(row.payload).destination,address);
 assert.equal((await request({...payload,origin:address+'x'})).status,400);
});
test('job trash and restore keep linked data, hide cards, counters, tracking and prevent stale edits',async()=>{
 const data={reference:'TRASH-TEST',origin:'Private origin',destination:'Private destination',status:'planned',public_origin:'Madrid',public_destination:'Paris',customer_code:'TRASH-CUSTOMER',equipment:'curtain'};
 const created=await call('admin/job',data,owner);assert.equal(created.status,200);const id=created.data.id;
 const detail=async()=> (await call('admin/job-detail?id='+id,null,owner)).data.job;
 let job=await detail();const action=j=>({id:j.id,kind:j.kind,reference:j.reference,load_revision:j.load_revision,shipment_revision:j.shipment_revision});
 const fin={job_id:id,revision:0,sale_currency:'EUR',purchase_currency:'EUR',sale_amount:'1000',purchase_amount:'800',received_amount:'0',paid_amount:'0',receivable_due:'',payable_due:''};assert.equal((await call('admin/finance',fin,owner)).status,200);
 const before=(await call('stats')).data;const body=action(job);
 assert.equal((await call('admin/job/trash',body)).status,401);assert.equal((await call('admin/job/trash',body,other)).status,403);assert.equal((await call('admin/job/trash',body,owner,'https://evil.test')).status,403);
 assert.equal((await call('admin/job/trash',{...body,reference:'WRONG'},owner)).status,400);
 assert.equal((await call('admin/job/trash',body,owner)).status,200);
 assert.equal((await call('admin/job/trash',body,owner)).status,409);
 assert.equal((await call('admin/job-detail?id='+id,null,owner)).status,404);
 assert.equal((await call('admin/finances?search=TRASH-TEST',null,owner)).data.rows.length,0);
 assert.equal((await call('admin/jobs?view=all&search=TRASH-TEST',null,owner)).data.jobs.length,0);
 assert.equal((await call('active-transports?id='+id)).data.transports.length,0);
 assert.equal((await call('stats')).data.activeShipments,before.activeShipments-1);
 assert.equal((await call('track',{reference:data.reference,accessKey:created.data.accessKey})).status,404);
 assert.equal((await call('admin/job',{...data,...body},owner)).data.error,'job_in_trash');
 assert.equal((await call('admin/shipment/key',{id:created.data.shipment_id},owner)).data.error,'job_in_trash');
 let trash=(await call('admin/jobs?view=trash&search=TRASH-TEST',null,owner)).data.jobs;assert.equal(trash.length,1);assert.equal(trash[0].status,'planned');
 assert.equal((await call('admin/job/restore',body,owner)).status,409);
 assert.equal((await call('admin/job/restore',action(trash[0]),owner)).status,200);
 assert.equal((await call('admin/finance?job_id='+id,null,owner)).data.finance.sale_cents,100000);
 job=await detail();assert.equal(job.shipment_id,created.data.shipment_id);assert.equal(job.status,'planned');assert.equal((await call('stats')).data.activeShipments,before.activeShipments);
 assert.equal((await call('track',{reference:data.reference,accessKey:created.data.accessKey})).status,200);
 const delivered=await call('admin/job',{...job,status:'delivered'},owner);assert.equal(delivered.status,200);job=await detail();const counts=(await call('stats')).data;
 assert.equal((await call('admin/job/trash',action(job),owner)).status,200);assert.equal((await call('stats')).data.deliveredShipments,counts.deliveredShipments);assert.equal((await call('stats')).data.servedCustomers,counts.servedCustomers);
});
test('untracked drafts and legacy standalone shipments can be trashed and restored without conversion',async()=>{
 const d=await call('admin/job',{reference:'TRASH-DRAFT',origin:'A',destination:'B',status:'draft',eta:'2026-11-10',tractor_plate:'KEEP'},owner);assert.equal(d.status,200);
 const s=await call('admin/shipment',{reference:'TRASH-LEGACY',origin:'A',destination:'B',status:'planned',eta:'',location:'',notes:{en:'',es:'',tr:''}},owner);assert.equal(s.status,200);
 for(const id of [d.data.id,s.data.id]){let j=(await call('admin/job-detail?id='+id,null,owner)).data.job;const original=j;
 assert.equal((await call('admin/job/trash',{...j},owner)).status,200);j=(await call('admin/jobs?view=trash',null,owner)).data.jobs.find(x=>x.id===id);assert.ok(j);
 assert.equal((await call('admin/job/restore',{...j},owner)).status,200);j=(await call('admin/job-detail?id='+id,null,owner)).data.job;assert.equal(j.kind,original.kind);assert.equal(j.shipment_id,original.shipment_id);assert.equal(j.tractor_plate,original.tractor_plate);assert.equal(j.eta,original.eta);}
});
