from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
import json
root=Path(__file__).resolve().parents[1]/'public'
class P(HTMLParser):
 def __init__(self):super().__init__();self.ids=[];self.links=[];self.assets=[];self.lang=None;self.text=[]
 def handle_starttag(self,t,a):
  a=dict(a)
  if t=='html':self.lang=a.get('lang')
  if 'id' in a:self.ids.append(a['id'])
  if t=='a' and a.get('href'):self.links.append(a['href'])
  if t in ['script','img','link']:
   u=a.get('src') if t!='link' else a.get('href') if a.get('rel')=='stylesheet' else None
   if u:self.assets.append(u)
 def handle_data(self,s):
  if s.strip():self.text.append(s.strip())
pages={}
for file in root.glob('*.html'):
 p=P();p.feed(file.read_text());pages[file.name]=p
 assert p.lang in ['en','es','tr'],file
 assert len(p.ids)==len(set(p.ids)),file
 for u in p.assets:
  if not u.startswith(('http','data:')):assert (root/u.lstrip('/')).is_file(),(file,u)
for name,p in pages.items():
 for u in p.links:
  link=urlsplit(u)
  if link.scheme or link.path.startswith('/signin'):continue
  filename=link.path.lstrip('/') or name
  if filename in pages and link.fragment:assert unquote(link.fragment) in pages[filename].ids,(name,u)
  elif filename not in pages:assert (root/filename).exists(),(name,u)
print(f'PASS: {len(pages)} pages, locale identities, unique IDs, all internal links and assets')
i=json.loads((root.parent/'source/operations-i18n.json').read_text());assert set(i['en'])==set(i['es'])==set(i['tr'])
for name,p in pages.items():
 if p.lang!='tr':
  forbidden=['Yük ekle','Talebi gönder','Sevkiyatı sorgula','Yönetim girişi','Yeni takip bağlantısı oluştur','Yük takibi']
  assert not(set(p.text)&set(forbidden)),name
print('PASS: complete operation dictionaries and no Turkish UI leaks on EN/ES pages')
