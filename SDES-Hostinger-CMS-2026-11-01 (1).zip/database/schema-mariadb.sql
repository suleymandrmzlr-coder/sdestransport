-- MariaDB 10.6+ / Hostinger Business or Cloud. No default credentials.
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS `admins` (
`user_id` VARCHAR(200) NOT NULL PRIMARY KEY,
`created_at` VARCHAR(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE IF NOT EXISTS `quotes` (
`id` VARCHAR(200) NOT NULL PRIMARY KEY,
`company` LONGTEXT NOT NULL,
`email` LONGTEXT NOT NULL,
`language` LONGTEXT NOT NULL,
`load_id` VARCHAR(200),
`payload` LONGTEXT NOT NULL,
`status` VARCHAR(30) NOT NULL,
`ip_hash` VARCHAR(200) NOT NULL,
`created_at` VARCHAR(40) NOT NULL,
`follow_up_date` VARCHAR(10) NOT NULL DEFAULT '',
`internal_notes` TEXT NOT NULL DEFAULT '',
`revision` BIGINT NOT NULL DEFAULT 1,
`updated_at` VARCHAR(40) NOT NULL DEFAULT '',
KEY `quote_rate` (`ip_hash`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE IF NOT EXISTS `loads` (
`id` VARCHAR(200) NOT NULL PRIMARY KEY,
`reference` VARCHAR(200) NOT NULL,
`origin` LONGTEXT NOT NULL,
`destination` LONGTEXT NOT NULL,
`pickup_date` VARCHAR(10) NOT NULL,
`equipment` LONGTEXT NOT NULL,
`weight` DOUBLE,
`pallets` BIGINT,
`status` VARCHAR(30) NOT NULL,
`details` LONGTEXT NOT NULL,
`revision` BIGINT NOT NULL DEFAULT 1,
`updated_at` VARCHAR(40) NOT NULL,
`origin_country` TEXT NOT NULL DEFAULT '',
`destination_country` TEXT NOT NULL DEFAULT '',
`customer_code` VARCHAR(100) NOT NULL DEFAULT '',
`carrier_name` TEXT NOT NULL DEFAULT '',
`public_origin` TEXT NOT NULL DEFAULT '',
`public_destination` TEXT NOT NULL DEFAULT '',
`source_quote_id` VARCHAR(200),
`intake` TEXT NOT NULL DEFAULT '{}',
`deleted_at` VARCHAR(40) NOT NULL DEFAULT '',
UNIQUE KEY `loads_source_quote_id_unique` (`source_quote_id`),
UNIQUE KEY `loads_reference_unique` (`reference`),
KEY loads_status_date(status,deleted_at,pickup_date),
CONSTRAINT fk_load_quote FOREIGN KEY(source_quote_id) REFERENCES quotes(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE IF NOT EXISTS `shipments` (
`id` VARCHAR(200) NOT NULL PRIMARY KEY,
`reference` VARCHAR(200) NOT NULL,
`origin` LONGTEXT NOT NULL,
`destination` LONGTEXT NOT NULL,
`eta` VARCHAR(10) NOT NULL,
`status` VARCHAR(30) NOT NULL,
`location` LONGTEXT NOT NULL,
`access_hash` LONGTEXT NOT NULL,
`revision` BIGINT NOT NULL DEFAULT 1,
`updated_at` VARCHAR(40) NOT NULL,
`tractor_plate` TEXT NOT NULL DEFAULT '',
`trailer_plate` TEXT NOT NULL DEFAULT '',
`load_id` VARCHAR(200),
`public_origin` TEXT NOT NULL DEFAULT '',
`public_destination` TEXT NOT NULL DEFAULT '',
`deleted_at` VARCHAR(40) NOT NULL DEFAULT '',
UNIQUE KEY `shipments_load_id_unique` (`load_id`),
UNIQUE KEY `shipments_reference_unique` (`reference`),
KEY shipments_status(status,deleted_at),
CONSTRAINT fk_shipment_load FOREIGN KEY(load_id) REFERENCES loads(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE IF NOT EXISTS `shipment_events` (
`id` VARCHAR(200) NOT NULL PRIMARY KEY,
`shipment_id` VARCHAR(200) NOT NULL,
`status` VARCHAR(30) NOT NULL,
`location` LONGTEXT NOT NULL,
`notes` LONGTEXT NOT NULL,
`created_at` VARCHAR(40) NOT NULL,
KEY `shipment_events_shipment` (`shipment_id`),
CONSTRAINT fk_event_shipment FOREIGN KEY(shipment_id) REFERENCES shipments(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE IF NOT EXISTS `articles` (
`slug` VARCHAR(200) NOT NULL PRIMARY KEY,
`status` VARCHAR(30) NOT NULL,
`content` LONGTEXT NOT NULL,
`revision` BIGINT NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE IF NOT EXISTS `hidden_demos` (
`id` VARCHAR(200) NOT NULL PRIMARY KEY,
`deleted_at` VARCHAR(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE IF NOT EXISTS `job_documents` (
`id` VARCHAR(200) NOT NULL PRIMARY KEY,
`job_id` VARCHAR(200) NOT NULL,
`type` LONGTEXT NOT NULL,
`language` LONGTEXT NOT NULL,
`number` VARCHAR(200) NOT NULL,
`created_at` VARCHAR(40) NOT NULL,
`created_by` LONGTEXT NOT NULL,
`object_key` LONGTEXT NOT NULL,
`snapshot` LONGTEXT NOT NULL,
KEY `job_documents_job` (`job_id`,`created_at`),
UNIQUE KEY `job_documents_number_unique` (`number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE IF NOT EXISTS `regular_routes` (
`id` VARCHAR(200) NOT NULL PRIMARY KEY,
`company` LONGTEXT NOT NULL,
`email` VARCHAR(200) NOT NULL,
`customer_code` VARCHAR(100) NOT NULL DEFAULT '',
`origin` LONGTEXT NOT NULL,
`destination` LONGTEXT NOT NULL,
`loading_gps` TEXT NOT NULL DEFAULT '',
`unloading_gps` TEXT NOT NULL DEFAULT '',
`departures_per_week` BIGINT NOT NULL,
`start_date` LONGTEXT NOT NULL,
`end_date` TEXT NOT NULL DEFAULT '',
`equipment` LONGTEXT NOT NULL,
`load_type` LONGTEXT NOT NULL,
`loading_metres` DOUBLE,
`return_load` LONGTEXT NOT NULL,
`schedule_notes` TEXT NOT NULL DEFAULT '',
`notes` TEXT NOT NULL DEFAULT '',
`status` VARCHAR(30) NOT NULL,
`revision` BIGINT NOT NULL DEFAULT 1,
`created_at` VARCHAR(40) NOT NULL,
`updated_at` VARCHAR(40) NOT NULL,
KEY `regular_routes_status` (`status`,`updated_at`),
KEY `regular_routes_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE IF NOT EXISTS `finance_history` (
`id` VARCHAR(200) NOT NULL PRIMARY KEY,
`job_id` VARCHAR(200) NOT NULL,
`revision` BIGINT NOT NULL,
`snapshot` LONGTEXT NOT NULL,
`created_by` LONGTEXT NOT NULL,
`created_at` VARCHAR(40) NOT NULL,
KEY `finance_history_job` (`job_id`,`revision`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE IF NOT EXISTS `job_finance` (
`job_id` VARCHAR(200) NOT NULL PRIMARY KEY,
`sale_currency` LONGTEXT NOT NULL,
`purchase_currency` LONGTEXT NOT NULL,
`sale_cents` BIGINT,
`purchase_cents` BIGINT,
`received_cents` BIGINT NOT NULL DEFAULT 0,
`paid_cents` BIGINT NOT NULL DEFAULT 0,
`receivable_due` TEXT NOT NULL DEFAULT '',
`payable_due` TEXT NOT NULL DEFAULT '',
`customer_document` TEXT NOT NULL DEFAULT '',
`carrier_document` TEXT NOT NULL DEFAULT '',
`notes` TEXT NOT NULL DEFAULT '',
`revision` BIGINT NOT NULL DEFAULT 1,
`updated_at` VARCHAR(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE IF NOT EXISTS cms_users(id VARCHAR(80) PRIMARY KEY,email VARCHAR(200) NOT NULL UNIQUE,name VARCHAR(180) NOT NULL,password_hash VARCHAR(255) NOT NULL,role VARCHAR(20) NOT NULL,permissions LONGTEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,revision INTEGER NOT NULL DEFAULT 1,created_at VARCHAR(40) NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
CREATE TABLE IF NOT EXISTS cms_sessions(token_hash VARCHAR(64) PRIMARY KEY,user_id VARCHAR(80) NOT NULL,expires_at BIGINT NOT NULL,INDEX session_user(user_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
CREATE TABLE IF NOT EXISTS cms_login_limits(bucket VARCHAR(128) PRIMARY KEY,attempts INTEGER NOT NULL,expires_at BIGINT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
CREATE TABLE IF NOT EXISTS cms_languages(code VARCHAR(12) PRIMARY KEY,name VARCHAR(80) NOT NULL,enabled INTEGER NOT NULL DEFAULT 0) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
CREATE TABLE IF NOT EXISTS cms_pages(id VARCHAR(120) PRIMARY KEY,template VARCHAR(160) NOT NULL,title VARCHAR(200) NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
CREATE TABLE IF NOT EXISTS cms_content(page_id VARCHAR(120) NOT NULL,locale VARCHAR(12) NOT NULL,slug VARCHAR(160) NOT NULL,title VARCHAR(250) NOT NULL,description TEXT NOT NULL,fields LONGTEXT NOT NULL,revision INTEGER NOT NULL DEFAULT 1,noindex INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(page_id,locale),UNIQUE KEY page_locale_slug(locale,slug)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
CREATE TABLE IF NOT EXISTS cms_redirects(old_path VARCHAR(200) PRIMARY KEY,new_path VARCHAR(200) NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
CREATE TABLE IF NOT EXISTS cms_settings(id VARCHAR(60) PRIMARY KEY,value LONGTEXT NOT NULL,revision INTEGER NOT NULL DEFAULT 1) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
CREATE TABLE IF NOT EXISTS cms_ui(locale VARCHAR(12) PRIMARY KEY,value LONGTEXT NOT NULL,revision INTEGER NOT NULL DEFAULT 1) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
CREATE TABLE IF NOT EXISTS cms_audit(id VARCHAR(80) PRIMARY KEY,user_id VARCHAR(80) NOT NULL,action VARCHAR(80) NOT NULL,target VARCHAR(200) NOT NULL,created_at VARCHAR(40) NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
CREATE TABLE IF NOT EXISTS stored_objects(object_key VARCHAR(200) PRIMARY KEY,content_type VARCHAR(100) NOT NULL,content LONGBLOB NOT NULL,created_at VARCHAR(40) NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
